/**
 * Core Module Tests
 * 
 * Comprehensive test suite for the core engine and validator modules.
 * Tests cover initialization, processing, validation, and error handling.
 */

import { Engine } from '../src/core/engine';
import { Validator, schemas } from '../src/core/validator';
import { Logger } from '../src/utils/logger';

// Mock logger for testing
const mockLogger = {
  debug: jest.fn(),
  info: jest.fn(),
  warn: jest.fn(),
  error: jest.fn(),
  trace: jest.fn(),
} as unknown as Logger;

describe('Engine', () => {
  let engine: Engine;

  beforeEach(() => {
    jest.clearAllMocks();
    engine = new Engine(mockLogger, {
      concurrency: 5,
      timeout: 30000,
    });
  });

  afterEach(async () => {
    if (engine) {
      await engine.shutdown();
    }
  });

  describe('initialization', () => {
    it('should initialize successfully', async () => {
      await expect(engine.initialize()).resolves.not.toThrow();
      expect(mockLogger.debug).toHaveBeenCalledWith(
        'Initializing engine',
        expect.objectContaining({
          concurrency: 5,
          timeout: 30000,
        })
      );
    });

    it('should not reinitialize if already initialized', async () => {
      await engine.initialize();
      await engine.initialize();
      expect(mockLogger.warn).toHaveBeenCalledWith('Engine already initialized');
    });
  });

  describe('processing', () => {
    beforeEach(async () => {
      await engine.initialize();
    });

    it('should process single item successfully', async () => {
      const input = {
        type: 'test',
        items: [{ id: 1, name: 'Test Item' }],
      };

      const result = await engine.process(input);

      expect(result.successCount).toBe(1);
      expect(result.failureCount).toBe(0);
      expect(result.results).toHaveLength(1);
      expect(result.results[0].success).toBe(true);
    });

    it('should process multiple items', async () => {
      const input = {
        type: 'test',
        items: [
          { id: 1, name: 'Item 1' },
          { id: 2, name: 'Item 2' },
          { id: 3, name: 'Item 3' },
        ],
      };

      const result = await engine.process(input);

      expect(result.successCount).toBe(3);
      expect(result.failureCount).toBe(0);
      expect(result.results).toHaveLength(3);
    });

    it('should handle empty items array', async () => {
      const input = {
        type: 'test',
        items: [],
      };

      const result = await engine.process(input);

      expect(result.successCount).toBe(0);
      expect(result.failureCount).toBe(0);
      expect(result.results).toHaveLength(0);
    });

    it('should handle items without array', async () => {
      const input = {
        type: 'test',
      };

      const result = await engine.process(input);

      expect(result.successCount).toBe(1);
      expect(result.failureCount).toBe(0);
    });

    it('should validate input structure', async () => {
      const input = null as unknown;

      const result = await engine.process(input as any);

      expect(result.failureCount).toBe(1);
      expect(result.errors).toHaveLength(1);
      expect(result.errors[0].error).toContain('null or undefined');
    });

    it('should require type property', async () => {
      const input = { items: [] };

      const result = await engine.process(input);

      expect(result.failureCount).toBe(1);
      expect(result.errors[0].error).toContain('type');
    });

    it('should process with concurrency control', async () => {
      const items = Array.from({ length: 20 }, (_, i) => ({ id: i + 1 }));
      const input = { type: 'test', items };

      const result = await engine.process(input);

      expect(result.successCount).toBe(20);
      expect(result.failureCount).toBe(0);
    });

    it('should add processing metadata to results', async () => {
      const input = {
        type: 'test',
        items: [{ id: 1, name: 'Test' }],
      };

      const result = await engine.process(input);

      expect(result.results[0].data).toMatchObject({
        id: 1,
        name: 'Test',
        processed: true,
        processedAt: expect.any(String),
        requestId: expect.stringMatching(/^req_/),
      });
    });
  });

  describe('error handling', () => {
    beforeEach(async () => {
      await engine.initialize();
    });

    it('should handle validation errors gracefully', async () => {
      const input = {
        type: 'test',
        items: [null],
      };

      const result = await engine.process(input);

      expect(result.failureCount).toBeGreaterThanOrEqual(0);
      expect(result.results).toHaveLength(1);
    });

    it('should record errors with timestamps', async () => {
      const input = {
        type: 'test',
        items: [{}],
      };

      const result = await engine.process(input);

      if (result.errors.length > 0) {
        expect(result.errors[0].timestamp).toMatch(
          /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}/
        );
      }
    });
  });

  describe('shutdown', () => {
    it('should shutdown gracefully', async () => {
      await engine.initialize();
      await expect(engine.shutdown()).resolves.not.toThrow();
      expect(mockLogger.info).toHaveBeenCalledWith('Engine shutdown complete');
    });
  });
});

describe('Validator', () => {
  let validator: Validator;

  beforeEach(async () => {
    jest.clearAllMocks();
    validator = new Validator(mockLogger);
    await validator.initialize();
  });

  describe('basic validation', () => {
    it('should validate non-null values', () => {
      const result = validator.validate({});
      expect(result.valid).toBe(true);
    });

    it('should reject null values', () => {
      const result = validator.validate(null);
      expect(result.valid).toBe(false);
      expect(result.errors).toContainEqual(
        expect.objectContaining({ field: 'root' })
      );
    });

    it('should reject undefined values', () => {
      const result = validator.validate(undefined);
      expect(result.valid).toBe(false);
    });
  });

  describe('schema validation', () => {
    it('should validate against user schema', () => {
      const validUser = {
        name: 'John Doe',
        email: 'john@example.com',
        age: 30,
      };

      const result = validator.validate(validUser, schemas.user);
      expect(result.valid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });

    it('should reject invalid email', () => {
      const invalidUser = {
        name: 'John Doe',
        email: 'not-an-email',
        age: 30,
      };

      const result = validator.validate(invalidUser, schemas.user);
      expect(result.valid).toBe(false);
      expect(result.errors.some((e) => e.field === 'email')).toBe(true);
    });

    it('should reject missing required fields', () => {
      const incompleteUser = {
        email: 'john@example.com',
      };

      const result = validator.validate(incompleteUser, schemas.user);
      expect(result.valid).toBe(false);
      expect(result.errors.some((e) => e.field === 'name')).toBe(true);
    });

    it('should validate string length constraints', () => {
      const user = {
        name: '',
        email: 'test@example.com',
      };

      const result = validator.validate(user, schemas.user);
      expect(result.valid).toBe(false);
      expect(result.errors[0].message).toContain('at least');
    });

    it('should validate number ranges', () => {
      const user = {
        name: 'John',
        email: 'john@example.com',
        age: -5,
      };

      const result = validator.validate(user, schemas.user);
      expect(result.valid).toBe(false);
      expect(result.errors.some((e) => e.field === 'age')).toBe(true);
    });
  });

  describe('custom validation rules', () => {
    it('should create required rule', () => {
      const rule = Validator.required();
      
      expect(rule('')).toBe('Field is required');
      expect(rule(null)).toBe('Field is required');
      expect(rule(undefined)).toBe('Field is required');
      expect(rule('value')).toBe(true);
    });

    it('should create string rule with constraints', () => {
      const rule = Validator.string({ minLength: 3, maxLength: 10 });
      
      expect(rule('ab')).toContain('at least');
      expect(rule('abcdefghijk')).toContain('at most');
      expect(rule('hello')).toBe(true);
    });

    it('should create number rule with constraints', () => {
      const rule = Validator.number({ min: 0, max: 100, integer: true });
      
      expect(rule(-1)).toContain('at least');
      expect(rule(101)).toContain('at most');
      expect(rule(3.5)).toContain('integer');
      expect(rule(50)).toBe(true);
    });

    it('should create email validation rule', () => {
      const rule = Validator.email();
      
      expect(rule('not-email')).toContain('email');
      expect(rule('valid@example.com')).toBe(true);
    });

    it('should create URL validation rule', () => {
      const rule = Validator.url();
      
      expect(rule('not-url')).toContain('URL');
      expect(rule('https://example.com')).toBe(true);
    });

    it('should create enum validation rule', () => {
      const rule = Validator.enum(['active', 'inactive', 'pending']);
      
      expect(rule('deleted')).toContain('active, inactive, pending');
      expect(rule('active')).toBe(true);
    });

    it('should create array validation rule', () => {
      const rule = Validator.array({ minLength: 1, maxLength: 5 });
      
      expect(rule([])).toContain('at least');
      expect(rule([1, 2, 3, 4, 5, 6])).toContain('at most');
      expect(rule([1, 2, 3])).toBe(true);
    });
  });

  describe('custom validators', () => {
    it('should create custom validation rule', () => {
      const rule = Validator.custom(
        (value) => typeof value === 'string' && value.length > 5,
        'Value must be a string longer than 5 characters'
      );

      expect(rule('short')).toContain('longer than 5');
      expect(rule('long enough')).toBe(true);
    });

    it('should access other fields in custom validator', () => {
      const rule = Validator.custom(
        (value, data) => {
          if (!data) return false;
          const confirm = (data as Record<string, unknown>).confirm;
          return value === confirm;
        },
        'Values do not match'
      );

      expect(rule('password', { confirm: 'different' })).toContain('do not match');
      expect(rule('password', { confirm: 'password' })).toBe(true);
    });
  });

  describe('pagination schema', () => {
    it('should validate valid pagination', () => {
      const validPagination = { page: 1, limit: 20 };
      const result = validator.validate(validPagination, schemas.pagination);
      expect(result.valid).toBe(true);
    });

    it('should reject page less than 1', () => {
      const invalidPagination = { page: 0, limit: 20 };
      const result = validator.validate(invalidPagination, schemas.pagination);
      expect(result.valid).toBe(false);
    });

    it('should reject limit greater than 100', () => {
      const invalidPagination = { page: 1, limit: 200 };
      const result = validator.validate(invalidPagination, schemas.pagination);
      expect(result.valid).toBe(false);
    });
  });
});

describe('Logger', () => {
  describe('instance creation', () => {
    it('should create logger with default options', () => {
      const logger = new Logger({
        level: 'info',
        format: 'json',
      });
      expect(logger).toBeDefined();
      expect(logger.getLevel()).toBe('info');
    });

    it('should create logger with all options', () => {
      const logger = new Logger({
        level: 'debug',
        format: 'pretty',
        destinations: ['console'],
        file: {
          path: './test.log',
          maxSize: '5m',
          maxFiles: 3,
        },
      });
      expect(logger).toBeDefined();
    });

    it('should set and get log level', () => {
      const logger = new Logger({ level: 'info', format: 'json' });
      expect(logger.getLevel()).toBe('info');
      logger.setLevel('debug');
      expect(logger.getLevel()).toBe('debug');
    });

    it('should check if level is enabled', () => {
      const logger = new Logger({ level: 'info', format: 'json' });
      expect(logger.isLevelEnabled('debug')).toBe(false);
      expect(logger.isLevelEnabled('info')).toBe(true);
      expect(logger.isLevelEnabled('error')).toBe(true);
    });
  });
});
