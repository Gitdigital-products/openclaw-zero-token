/**
 * Utility Module Tests
 * 
 * Comprehensive test suite for utility functions including
 * formatting, helpers, and template generation.
 */

import {
  formatDate,
  formatCurrency,
  formatNumber,
  formatPercentage,
  formatFileSize,
  formatDuration,
  formatTable,
  truncate,
  camelToKebab,
  kebabToCamel,
  camelToSnake,
  snakeToCamel,
  capitalize,
  toTitleCase,
  escapeHtml,
  unescapeHtml,
  formatPhone,
  formatRelativeTime,
  formatJson,
} from '../src/utils/formatter';

import {
  isPlainObject,
  isString,
  isNumber,
  isBoolean,
  isArray,
  isFunction,
  isNil,
  isEmpty,
  isEmail,
  isUrl,
  isUuid,
  randomString,
  randomNumber,
  pickRandom,
  deepClone,
  deepMerge,
  omit,
  pick,
  groupBy,
  chunk,
  flatten,
  unique,
  validateEnvironment,
  getEnvironment,
  isProduction,
  isDevelopment,
  safeJsonParse,
  retry,
  sleep,
} from '../src/utils/helpers';

import {
  renderMarkdown,
  renderChangelogEntry,
  renderApiDoc,
  compileTemplate,
  markdownToHtml,
  generateConfig,
  generateDevelopmentConfig,
  generateProductionConfig,
  generateTestConfig,
} from '../src/templates/markdown';
import { generateDockerCompose, generateKubernetesManifest } from '../src/templates/config';

describe('Formatter Utilities', () => {
  describe('formatDate', () => {
    it('should format date with ISO format', () => {
      const date = new Date('2024-01-15T10:30:00Z');
      const result = formatDate(date);
      expect(result).toContain('2024');
    });

    it('should format date with custom format', () => {
      const date = new Date('2024-01-15');
      const result = formatDate(date, 'yyyy-MM-dd');
      expect(result).toBe('2024-01-15');
    });

    it('should handle string date input', () => {
      const result = formatDate('2024-01-15', 'yyyy-MM-dd');
      expect(result).toBe('2024-01-15');
    });

    it('should handle timestamp input', () => {
      const timestamp = 1705315800000;
      const result = formatDate(timestamp, 'yyyy-MM-dd');
      expect(result).toBe('2024-01-15');
    });

    it('should return Invalid Date for invalid input', () => {
      const result = formatDate('not-a-date' as any);
      expect(result).toBe('Invalid Date');
    });
  });

  describe('formatCurrency', () => {
    it('should format USD by default', () => {
      const result = formatCurrency(1234.56);
      expect(result).toBe('$1,234.56');
    });

    it('should format EUR correctly', () => {
      const result = formatCurrency(1234.56, 'EUR');
      expect(result).toBe('€1,234.56');
    });

    it('should format without symbol', () => {
      const result = formatCurrency(1234.56, 'USD', { showSymbol: false });
      expect(result).toBe('1,234.56');
    });

    it('should handle zero decimals', () => {
      const result = formatCurrency(1234, 'USD', { decimals: 0 });
      expect(result).toBe('$1,234');
    });

    it('should format negative values', () => {
      const result = formatCurrency(-1234.56);
      expect(result).toContain('-');
    });
  });

  describe('formatNumber', () => {
    it('should format with thousand separators', () => {
      const result = formatNumber(1234567);
      expect(result).toBe('1,234,567');
    });

    it('should format with decimals', () => {
      const result = formatNumber(1234.567, { decimals: 2 });
      expect(result).toBe('1,234.57');
    });

    it('should format with custom separators', () => {
      const result = formatNumber(1234.5, {
        decimalSeparator: ',',
        thousandSeparator: '.',
      });
      expect(result).toBe('1.234,50');
    });
  });

  describe('formatPercentage', () => {
    it('should format percentage from decimal', () => {
      const result = formatPercentage(0.5);
      expect(result).toBe('50.0%');
    });

    it('should format with custom decimals', () => {
      const result = formatPercentage(0.333, { decimals: 2 });
      expect(result).toBe('33.30%');
    });

    it('should format from whole number', () => {
      const result = formatPercentage(50, { multiplier: false });
      expect(result).toBe('50.0%');
    });

    it('should show positive sign', () => {
      const result = formatPercentage(0.05, { showSign: true });
      expect(result).toBe('+5.0%');
    });
  });

  describe('formatFileSize', () => {
    it('should format bytes', () => {
      const result = formatFileSize(500);
      expect(result).toBe('500 Bytes');
    });

    it('should format kilobytes', () => {
      const result = formatFileSize(1024);
      expect(result).toBe('1.00 KB');
    });

    it('should format megabytes', () => {
      const result = formatFileSize(1024 * 1024);
      expect(result).toBe('1.00 MB');
    });

    it('should format gigabytes', () => {
      const result = formatFileSize(1024 * 1024 * 1024);
      expect(result).toBe('1.00 GB');
    });

    it('should handle zero bytes', () => {
      const result = formatFileSize(0);
      expect(result).toBe('0 Bytes');
    });
  });

  describe('formatDuration', () => {
    it('should format milliseconds', () => {
      const result = formatDuration(500);
      expect(result).toBe('500ms');
    });

    it('should format seconds', () => {
      const result = formatDuration(5000);
      expect(result).toBe('5s');
    });

    it('should format minutes', () => {
      const result = formatDuration(60000);
      expect(result).toBe('1m');
    });

    it('should format hours', () => {
      const result = formatDuration(3600000);
      expect(result).toBe('1h');
    });

    it('should format days', () => {
      const result = formatDuration(86400000);
      expect(result).toBe('1d');
    });

    it('should format complex duration', () => {
      const result = formatDuration(90061000); // 1d 1h 1m 1s
      expect(result).toBe('1d 1h 1m 1s');
    });

    it('should handle negative values', () => {
      const result = formatDuration(-100);
      expect(result).toBe('0ms');
    });
  });

  describe('formatTable', () => {
    it('should format simple table', () => {
      const rows = [
        { name: 'Alice', age: 30 },
        { name: 'Bob', age: 25 },
      ];
      const result = formatTable(rows);
      expect(result).toContain('name');
      expect(result).toContain('age');
      expect(result).toContain('Alice');
      expect(result).toContain('Bob');
    });

    it('should handle empty table', () => {
      const result = formatTable([]);
      expect(result).toBe('(empty table)');
    });

    it('should truncate long values', () => {
      const rows = [{ veryLongColumnName: 'a'.repeat(100) }];
      const result = formatTable(rows, { maxWidth: 50 });
      expect(result).toContain('...');
    });
  });

  describe('string utilities', () => {
    describe('truncate', () => {
      it('should truncate long strings', () => {
        const result = truncate('Hello World', 5);
        expect(result).toBe('Hello...');
      });

      it('should not truncate short strings', () => {
        const result = truncate('Hi', 10);
        expect(result).toBe('Hi');
      });

      it('should use custom suffix', () => {
        const result = truncate('Hello World', 5, '***');
        expect(result).toBe('He***');
      });
    });

    describe('camelToKebab', () => {
      it('should convert camelCase to kebab-case', () => {
        expect(camelToKebab('helloWorld')).toBe('hello-world');
        expect(camelToKebab('testValue123')).toBe('test-value123');
      });
    });

    describe('kebabToCamel', () => {
      it('should convert kebab-case to camelCase', () => {
        expect(kebabToCamel('hello-world')).toBe('helloWorld');
        expect(kebabToCamel('test-value')).toBe('testValue');
      });
    });

    describe('camelToSnake', () => {
      it('should convert camelCase to snake_case', () => {
        expect(camelToSnake('helloWorld')).toBe('hello_world');
      });
    });

    describe('snakeToCamel', () => {
      it('should convert snake_case to camelCase', () => {
        expect(snakeToCamel('hello_world')).toBe('helloWorld');
      });
    });

    describe('capitalize', () => {
      it('should capitalize first letter', () => {
        expect(capitalize('hello')).toBe('Hello');
        expect(capitalize('')).toBe('');
      });
    });

    describe('toTitleCase', () => {
      it('should convert to title case', () => {
        expect(toTitleCase('hello world')).toBe('Hello World');
        expect(toTitleCase('HELLO WORLD')).toBe('Hello World');
      });
    });

    describe('escapeHtml', () => {
      it('should escape HTML entities', () => {
        expect(escapeHtml('<div>&</div>')).toBe('&lt;div&gt;&amp;&lt;/div&gt;');
      });
    });

    describe('unescapeHtml', () => {
      it('should unescape HTML entities', () => {
        expect(unescapeHtml('&lt;div&gt;&amp;&lt;/div&gt;')).toBe('<div>&</div>');
      });
    });

    describe('formatPhone', () => {
      it('should format US phone numbers', () => {
        expect(formatPhone('5551234567')).toBe('(555) 123-4567');
      });

      it('should format with country code', () => {
        expect(formatPhone('15551234567')).toBe('+1 (555) 123-4567');
      });
    });
  });
});

describe('Helper Utilities', () => {
  describe('type checking', () => {
    describe('isPlainObject', () => {
      it('should return true for plain objects', () => {
        expect(isPlainObject({})).toBe(true);
        expect(isPlainObject({ a: 1 })).toBe(true);
      });

      it('should return false for non-objects', () => {
        expect(isPlainObject(null)).toBe(false);
        expect(isPlainObject([])).toBe(false);
        expect(isPlainObject(new Date())).toBe(false);
      });
    });

    describe('isString', () => {
      it('should return true for strings', () => {
        expect(isString('hello')).toBe(true);
        expect(isString('')).toBe(true);
      });

      it('should return false for non-strings', () => {
        expect(isString(123)).toBe(false);
        expect(isString(null)).toBe(false);
      });
    });

    describe('isNumber', () => {
      it('should return true for numbers', () => {
        expect(isNumber(123)).toBe(true);
        expect(isNumber(0)).toBe(true);
        expect(isNumber(-123)).toBe(true);
      });

      it('should return false for NaN', () => {
        expect(isNumber(NaN)).toBe(false);
      });
    });

    describe('isBoolean', () => {
      it('should return true for booleans', () => {
        expect(isBoolean(true)).toBe(true);
        expect(isBoolean(false)).toBe(true);
      });
    });

    describe('isArray', () => {
      it('should return true for arrays', () => {
        expect(isArray([])).toBe(true);
        expect(isArray([1, 2, 3])).toBe(true);
      });
    });

    describe('isFunction', () => {
      it('should return true for functions', () => {
        expect(isFunction(() => {})).toBe(true);
        expect(isFunction(Math.random)).toBe(true);
      });
    });

    describe('isNil', () => {
      it('should return true for null and undefined', () => {
        expect(isNil(null)).toBe(true);
        expect(isNil(undefined)).toBe(true);
      });
    });

    describe('isEmpty', () => {
      it('should return true for empty values', () => {
        expect(isEmpty(null)).toBe(true);
        expect(isEmpty(undefined)).toBe(true);
        expect(isEmpty('')).toBe(true);
        expect(isEmpty([])).toBe(true);
        expect(isEmpty({})).toBe(true);
      });
    });

    describe('isEmail', () => {
      it('should validate emails correctly', () => {
        expect(isEmail('test@example.com')).toBe(true);
        expect(isEmail('invalid')).toBe(false);
        expect(isEmail('test@')).toBe(false);
      });
    });

    describe('isUrl', () => {
      it('should validate URLs correctly', () => {
        expect(isUrl('https://example.com')).toBe(true);
        expect(isUrl('http://localhost:3000')).toBe(true);
        expect(isUrl('not-a-url')).toBe(false);
      });
    });

    describe('isUuid', () => {
      it('should validate UUIDs correctly', () => {
        expect(isUuid('550e8400-e29b-41d4-a716-446655440000')).toBe(true);
        expect(isUuid('not-a-uuid')).toBe(false);
      });
    });
  });

  describe('random utilities', () => {
    describe('randomString', () => {
      it('should generate string of specified length', () => {
        const result = randomString(10);
        expect(result).toHaveLength(10);
      });

      it('should use custom charset', () => {
        const result = randomString(10, '01');
        expect(result).toMatch(/^[01]+$/);
      });
    });

    describe('randomNumber', () => {
      it('should generate number in range', () => {
        for (let i = 0; i < 100; i++) {
          const result = randomNumber(1, 10);
          expect(result).toBeGreaterThanOrEqual(1);
          expect(result).toBeLessThanOrEqual(10);
        }
      });
    });

    describe('pickRandom', () => {
      it('should pick specified number of items', () => {
        const arr = [1, 2, 3, 4, 5];
        const result = pickRandom(arr, 3);
        expect(result).toHaveLength(3);
      });

      it('should not allow duplicates by default', () => {
        const arr = [1, 2, 3];
        const result = pickRandom(arr, 3);
        expect(new Set(result).size).toBe(3);
      });
    });
  });

  describe('object utilities', () => {
    describe('deepClone', () => {
      it('should clone objects deeply', () => {
        const original = { a: { b: { c: 1 } } };
        const cloned = deepClone(original);
        expect(cloned).toEqual(original);
        expect(cloned).not.toBe(original);
        expect(cloned.a).not.toBe(original.a);
      });

      it('should clone arrays deeply', () => {
        const original = [{ a: 1 }, { b: 2 }];
        const cloned = deepClone(original);
        expect(cloned).toEqual(original);
        expect(cloned[0]).not.toBe(original[0]);
      });

      it('should preserve Date objects', () => {
        const original = { date: new Date() };
        const cloned = deepClone(original);
        expect(cloned.date).toEqual(original.date);
        expect(cloned.date).not.toBe(original.date);
      });
    });

    describe('deepMerge', () => {
      it('should merge objects deeply', () => {
        const target = { a: { b: 1 }, c: 2 };
        const source = { a: { d: 3 } };
        const result = deepMerge(target, source);
        expect(result).toEqual({ a: { b: 1, d: 3 }, c: 2 });
      });

      it('should override with source values', () => {
        const target = { a: 1 };
        const source = { a: 2 };
        const result = deepMerge(target, source);
        expect(result.a).toBe(2);
      });
    });

    describe('omit', () => {
      it('should omit specified keys', () => {
        const obj = { a: 1, b: 2, c: 3 };
        const result = omit(obj, ['b'] as any);
        expect(result).toEqual({ a: 1, c: 3 });
      });
    });

    describe('pick', () => {
      it('should pick specified keys', () => {
        const obj = { a: 1, b: 2, c: 3 };
        const result = pick(obj, ['a', 'c'] as any);
        expect(result).toEqual({ a: 1, c: 3 });
      });
    });

    describe('groupBy', () => {
      it('should group array by key', () => {
        const arr = [
          { type: 'a', value: 1 },
          { type: 'b', value: 2 },
          { type: 'a', value: 3 },
        ];
        const result = groupBy(arr, (item) => item.type);
        expect(result.a).toHaveLength(2);
        expect(result.b).toHaveLength(1);
      });
    });

    describe('chunk', () => {
      it('should split array into chunks', () => {
        const arr = [1, 2, 3, 4, 5];
        const result = chunk(arr, 2);
        expect(result).toEqual([[1, 2], [3, 4], [5]]);
      });
    });

    describe('flatten', () => {
      it('should flatten nested arrays', () => {
        const arr = [1, [2, 3], [4, [5, 6]]];
        const result = flatten(arr);
        expect(result).toEqual([1, 2, 3, 4, 5, 6]);
      });
    });

    describe('unique', () => {
      it('should remove duplicates', () => {
        const arr = [1, 2, 2, 3, 3, 3];
        const result = unique(arr);
        expect(result).toEqual([1, 2, 3]);
      });

      it('should support custom key function', () => {
        const arr = [{ a: 1 }, { a: 1 }, { a: 2 }];
        const result = unique(arr, (item) => item.a);
        expect(result).toHaveLength(2);
      });
    });
  });

  describe('async utilities', () => {
    describe('retry', () => {
      it('should retry failed operations', async () => {
        let attempts = 0;
        const fn = jest.fn().mockImplementation(() => {
          attempts++;
          if (attempts < 3) throw new Error('Failed');
          return 'success';
        });

        const result = await retry(fn, { attempts: 3, delay: 10 });
        expect(result).toBe('success');
        expect(fn).toHaveBeenCalledTimes(3);
      });

      it('should throw after exhausting retries', async () => {
        const fn = jest.fn().mockRejectedValue(new Error('Always fails'));

        await expect(
          retry(fn, { attempts: 2, delay: 10 })
        ).rejects.toThrow('Always fails');
        expect(fn).toHaveBeenCalledTimes(2);
      });
    });

    describe('sleep', () => {
      it('should delay execution', async () => {
        const start = Date.now();
        await sleep(50);
        const elapsed = Date.now() - start;
        expect(elapsed).toBeGreaterThanOrEqual(45);
      });
    });
  });

  describe('safeJsonParse', () => {
    it('should parse valid JSON', () => {
      const result = safeJsonParse('{"a":1}', { a: 0 });
      expect(result).toEqual({ a: 1 });
    });

    it('should return fallback for invalid JSON', () => {
      const result = safeJsonParse('not json', { a: 0 });
      expect(result).toEqual({ a: 0 });
    });
  });
});

describe('Markdown Templates', () => {
  describe('renderMarkdown', () => {
    it('should render simple document', () => {
      const doc = {
        title: 'Test Document',
        description: 'A test document',
        sections: [
          {
            heading: 'Introduction',
            content: 'This is the introduction',
          },
        ],
      };

      const result = renderMarkdown(doc);
      expect(result).toContain('# Test Document');
      expect(result).toContain('## Introduction');
      expect(result).toContain('This is the introduction');
    });

    it('should render document with metadata', () => {
      const doc = {
        title: 'Test',
        metadata: { author: 'Test Author', date: '2024-01-15' },
        sections: [],
      };

      const result = renderMarkdown(doc);
      expect(result).toContain('---');
      expect(result).toContain('author: "Test Author"');
    });
  });

  describe('renderChangelogEntry', () => {
    it('should render changelog entry', () => {
      const entry = {
        version: '1.0.0',
        date: new Date('2024-01-15'),
        type: 'minor' as const,
        changes: [
          {
            category: 'Added',
            items: ['New feature added'],
          },
        ],
      };

      const result = renderChangelogEntry(entry);
      expect(result).toContain('## [1.0.0]');
      expect(result).toContain('### Added');
      expect(result).toContain('New feature added');
    });
  });

  describe('renderApiDoc', () => {
    it('should render API documentation', () => {
      const doc = {
        endpoint: '/api/users',
        method: 'GET',
        description: 'Get all users',
        parameters: [
          {
            name: 'page',
            type: 'number',
            required: false,
            description: 'Page number',
            location: 'query' as const,
          },
        ],
      };

      const result = renderApiDoc(doc);
      expect(result).toContain('### `GET` /api/users');
      expect(result).toContain('Get all users');
      expect(result).toContain('page');
    });
  });

  describe('compileTemplate', () => {
    it('should substitute variables', () => {
      const template = 'Hello {{name}}, you have {{count}} messages';
      const result = compileTemplate(template, { name: 'Alice', count: 5 });
      expect(result).toBe('Hello Alice, you have 5 messages');
    });

    it('should handle nested variables', () => {
      const template = 'User: {{user.name}}, Email: {{user.email}}';
      const result = compileTemplate(template, {
        user: { name: 'Alice', email: 'alice@example.com' },
      });
      expect(result).toBe('User: Alice, Email: alice@example.com');
    });

    it('should preserve unmatched variables', () => {
      const template = 'Hello {{name}}';
      const result = compileTemplate(template, {});
      expect(result).toBe('Hello {{name}}');
    });
  });
});

describe('Config Templates', () => {
  describe('generateConfig', () => {
    it('should generate JSON config', () => {
      const config = {
        app: { name: 'test', port: 3000 },
        logging: { level: 'info' },
      };

      const result = generateConfig(config, { format: 'json' });
      expect(result).toContain('"name": "test"');
      expect(result).toContain('"port": 3000');
    });

    it('should generate YAML config', () => {
      const config = {
        app: { name: 'test', port: 3000 },
      };

      const result = generateConfig(config, { format: 'yaml' });
      expect(result).toContain('app:');
      expect(result).toContain('name: test');
    });

    it('should generate ENV config', () => {
      const config = {
        app: { name: 'test', port: 3000 },
      };

      const result = generateConfig(config, { format: 'env' });
      expect(result).toContain('APP_NAME="test"');
      expect(result).toContain('APP_PORT=3000');
    });
  });

  describe('generateDevelopmentConfig', () => {
    it('should generate development config', () => {
      const result = generateDevelopmentConfig();
      expect(result).toContain('development');
      expect(result).toContain('debug');
    });
  });

  describe('generateProductionConfig', () => {
    it('should generate production config', () => {
      const result = generateProductionConfig();
      expect(result).toContain('production');
      expect(result).toContain('info');
    });
  });

  describe('generateDockerCompose', () => {
    it('should generate docker compose file', () => {
      const result = generateDockerCompose();
      expect(result).toContain('version:');
      expect(result).toContain('services:');
      expect(result).toContain('app:');
    });
  });

  describe('generateKubernetesManifest', () => {
    it('should generate Kubernetes manifest', () => {
      const result = generateKubernetesManifest({
        appName: 'my-app',
        image: 'my-app:latest',
      });
      expect(result).toContain('apiVersion: apps/v1');
      expect(result).toContain('kind: Deployment');
      expect(result).toContain('name: my-app');
    });
  });
});
