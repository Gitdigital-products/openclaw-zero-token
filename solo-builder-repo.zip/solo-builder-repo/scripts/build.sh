#!/bin/bash

# =============================================================================
# Build Script for Solo Builder Repository
# =============================================================================
# This script handles the build process for the project, including TypeScript
# compilation, asset processing, and output preparation.

set -e  # Exit on any error
set -u  # Exit on undefined variable
set -o pipefail  # Exit on pipe failure

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"

# Build configuration
BUILD_MODE="${BUILD_MODE:-production}"
BUILD_OUTPUT="${BUILD_OUTPUT:-$PROJECT_ROOT/dist}"
BUILD_CACHE="${BUILD_CACHE:-$PROJECT_ROOT/.build-cache}"

# Print functions
print_header() {
    echo -e "\n${BLUE}═══════════════════════════════════════════${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}═══════════════════════════════════════════${NC}\n"
}

print_success() {
    echo -e "${GREEN}✓${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}⚠${NC} $1"
}

print_error() {
    echo -e "${RED}✗${NC} $1"
}

print_info() {
    echo -e "${BLUE}ℹ${NC} $1"
}

# Change to project root
cd "$PROJECT_ROOT"

# Clean build output
clean() {
    print_header "Cleaning Build Output"

    if [ -d "$BUILD_OUTPUT" ]; then
        print_info "Removing $BUILD_OUTPUT"
        rm -rf "$BUILD_OUTPUT"
    fi

    if [ -d "$BUILD_CACHE" ]; then
        print_info "Removing $BUILD_CACHE"
        rm -rf "$BUILD_CACHE"
    fi

    print_success "Clean complete"
}

# Create build directories
create_build_dirs() {
    print_info "Creating build directories"

    mkdir -p "$BUILD_OUTPUT"
    mkdir -p "$BUILD_CACHE"

    print_success "Build directories created"
}

# TypeScript compilation
compile_typescript() {
    print_header "Compiling TypeScript"

    if ! command -v npx &> /dev/null; then
        print_error "npx is not available"
        exit 1
    fi

    print_info "Running TypeScript compiler..."

    if npx tsc --project tsconfig.json; then
        print_success "TypeScript compilation complete"
    else
        print_error "TypeScript compilation failed"
        exit 1
    fi
}

# Copy static assets
copy_assets() {
    print_header "Copying Static Assets"

    ASSETS_DIR="$PROJECT_ROOT/assets"
    DOCS_DIR="$PROJECT_ROOT/docs"

    # Copy assets if directory exists
    if [ -d "$ASSETS_DIR" ]; then
        print_info "Copying assets..."
        cp -r "$ASSETS_DIR" "$BUILD_OUTPUT/" 2>/dev/null || true
        print_success "Assets copied"
    fi

    # Copy docs if directory exists
    if [ -d "$DOCS_DIR" ]; then
        print_info "Copying documentation..."
        cp -r "$DOCS_DIR" "$BUILD_OUTPUT/" 2>/dev/null || true
        print_success "Documentation copied"
    fi

    # Copy README if exists
    if [ -f "$PROJECT_ROOT/README.md" ]; then
        cp "$PROJECT_ROOT/README.md" "$BUILD_OUTPUT/" 2>/dev/null || true
        print_success "README copied"
    fi

    # Copy LICENSE if exists
    if [ -f "$PROJECT_ROOT/LICENSE" ]; then
        cp "$PROJECT_ROOT/LICENSE" "$BUILD_OUTPUT/" 2>/dev/null || true
        print_success "LICENSE copied"
    fi
}

# Generate source map metadata
generate_source_map() {
    print_header "Generating Source Map Metadata"

    MAP_FILE="$BUILD_OUTPUT/source-map.json"

    cat > "$MAP_FILE" << EOF
{
  "version": "1.0.0",
  "buildMode": "$BUILD_MODE",
  "buildTime": "$(date -u +"%Y-%m-%dT%H:%M:%SZ")",
  "gitCommit": "$(git rev-parse HEAD 2>/dev/null || echo "unknown")",
  "gitBranch": "$(git rev-parse --abbrev-ref HEAD 2>/dev/null || echo "unknown")"
}
EOF

    print_success "Source map metadata generated"
}

# Bundle for production
bundle_production() {
    if [ "$BUILD_MODE" != "production" ]; then
        print_info "Skipping bundling (development mode)"
        return
    fi

    print_header "Bundling for Production"

    # Check if bundler is configured
    if [ -f "$PROJECT_ROOT/webpack.config.js" ] || [ -f "$PROJECT_ROOT/vite.config.ts" ]; then
        if [ -f "$PROJECT_ROOT/webpack.config.js" ]; then
            print_info "Running webpack..."
            npx webpack --config webpack.config.js --mode production || true
        fi

        if [ -f "$PROJECT_ROOT/vite.config.ts" ]; then
            print_info "Running Vite..."
            npx vite build || true
        fi
    else
        print_info "No bundler configuration found. Skipping bundle step."
    fi

    print_success "Bundling complete"
}

# Minify output
minify_output() {
    if [ "$BUILD_MODE" != "production" ]; then
        print_info "Skipping minification (development mode)"
        return
    fi

    print_header "Minifying Output"

    # Check for JavaScript files to potentially minify
    JS_FILES=$(find "$BUILD_OUTPUT" -name "*.js" -type f 2>/dev/null | wc -l)

    if [ "$JS_FILES" -gt 0 ]; then
        print_info "Found $JS_FILES JavaScript files"
        print_info "Note: For production minification, configure a bundler like webpack or esbuild"
    fi

    print_success "Minification complete"
}

# Verify build output
verify_build() {
    print_header "Verifying Build Output"

    local exit_code=0

    # Check if output directory exists
    if [ ! -d "$BUILD_OUTPUT" ]; then
        print_error "Build output directory not found"
        exit 1
    fi

    # Check for essential files
    if [ -f "$BUILD_OUTPUT/index.js" ] || [ -f "$BUILD_OUTPUT/index.ts" ]; then
        print_success "Entry point found"
    else
        print_warning "Entry point not found in build output"
    fi

    # Check for type declarations
    if ls "$BUILD_OUTPUT"/*.d.ts &>/dev/null; then
        TYPE_COUNT=$(ls "$BUILD_OUTPUT"/*.d.ts 2>/dev/null | wc -l)
        print_success "Type declarations found: $TYPE_COUNT files"
    else
        print_warning "No type declarations found"
    fi

    # Check for source maps
    if ls "$BUILD_OUTPUT"/*.js.map &>/dev/null; then
        print_success "Source maps found"
    else
        print_warning "No source maps found"
    fi

    # Report file counts
    JS_COUNT=$(find "$BUILD_OUTPUT" -name "*.js" -type f 2>/dev/null | wc -l)
    TS_COUNT=$(find "$BUILD_OUTPUT" -name "*.ts" -type f 2>/dev/null | wc -l)
    JSON_COUNT=$(find "$BUILD_OUTPUT" -name "*.json" -type f 2>/dev/null | wc -l)

    print_info "Build output summary:"
    echo "  - JavaScript files: $JS_COUNT"
    echo "  - TypeScript files: $TS_COUNT"
    echo "  - JSON files: $JSON_COUNT"

    print_success "Build verification complete"
}

# Display build summary
display_summary() {
    print_header "Build Summary"

    echo "
Build completed successfully!

Output directory: ${YELLOW}$BUILD_OUTPUT${NC}
Build mode:       ${YELLOW}$BUILD_MODE${NC}
Build time:       ${YELLOW}$(date)${NC}

To run the application:
  ${GREEN}npm start${NC}

To build again:
  ${GREEN}npm run build${NC}

To clean and rebuild:
  ${GREEN}npm run clean && npm run build${NC}
"
}

# Parse command line arguments
parse_args() {
    while [[ $# -gt 0 ]]; do
        case $1 in
            --clean)
                clean
                exit 0
                ;;
            --mode)
                BUILD_MODE="$2"
                shift 2
                ;;
            --output)
                BUILD_OUTPUT="$2"
                shift 2
                ;;
            --help)
                echo "Usage: $0 [options]"
                echo ""
                echo "Options:"
                echo "  --clean     Clean build output before building"
                echo "  --mode      Build mode (production, development) [default: production]"
                echo "  --output    Build output directory [default: dist]"
                echo "  --help      Show this help message"
                exit 0
                ;;
            *)
                print_error "Unknown option: $1"
                exit 1
                ;;
        esac
    done
}

# Main build function
main() {
    # Parse arguments
    parse_args "$@"

    echo ""
    echo -e "${BLUE}╔═══════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║   Solo Builder Repository Build           ║${NC}"
    echo -e "${BLUE}║   Building for $BUILD_MODE mode${NC}"
    echo -e "${BLUE}╚═══════════════════════════════════════════╝${NC}"
    echo ""

    # Run build steps
    clean
    create_build_dirs
    compile_typescript
    copy_assets
    generate_source_map
    bundle_production
    minify_output
    verify_build
    display_summary
}

# Run main function
main "$@"
