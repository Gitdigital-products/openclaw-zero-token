#!/bin/bash

# =============================================================================
# Setup Script for Solo Builder Repository
# =============================================================================
# This script initializes the development environment, installs dependencies,
# and configures the necessary tools for the project.

set -e  # Exit on any error
set -u  # Exit on undefined variable
set -o pipefail  # Exit on pipe failure

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"

# Print functions
print_header() {
    echo -e "\n${BLUE}========================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}========================================${NC}\n"
}

print_success() {
    echo -e "${GREEN}✓${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}⚠${NC} $1"
}

print_error() {
    echo -e "${RED}✗${NC} $1"
}

# Check prerequisites
check_prerequisites() {
    print_header "Checking Prerequisites"

    # Check Node.js
    if command -v node &> /dev/null; then
        NODE_VERSION=$(node --version)
        print_success "Node.js: $NODE_VERSION"

        # Check if Node.js version is 18 or higher
        NODE_MAJOR=$(echo "$NODE_VERSION" | sed 's/v\([0-9]*\).*/\1/')
        if [ "$NODE_MAJOR" -lt 18 ]; then
            print_error "Node.js version 18 or higher is required. Current: $NODE_VERSION"
            exit 1
        fi
    else
        print_error "Node.js is not installed. Please install Node.js 18 or higher."
        exit 1
    fi

    # Check npm
    if command -v npm &> /dev/null; then
        NPM_VERSION=$(npm --version)
        print_success "npm: $NPM_VERSION"
    else
        print_error "npm is not installed."
        exit 1
    fi

    # Check Git
    if command -v git &> /dev/null; then
        GIT_VERSION=$(git --version)
        print_success "Git: $GIT_VERSION"
    else
        print_warning "Git is not installed. Version control features will not be available."
    fi

    # Check for optional tools
    if command -v nvm &> /dev/null; then
        print_success "nvm is available (optional)"
    fi

    if command -v yarn &> /dev/null; then
        print_success "yarn is available (optional)"
    fi

    if command -v pnpm &> /dev/null; then
        print_success "pnpm is available (optional)"
    fi
}

# Create necessary directories
create_directories() {
    print_header "Creating Directories"

    DIRS=(
        "$PROJECT_ROOT/logs"
        "$PROJECT_ROOT/tmp"
        "$PROJECT_ROOT/dist"
        "$PROJECT_ROOT/coverage"
    )

    for dir in "${DIRS[@]}"; do
        if [ ! -d "$dir" ]; then
            mkdir -p "$dir"
            print_success "Created: $dir"
        else
            print_success "Exists: $dir"
        fi
    done
}

# Install dependencies
install_dependencies() {
    print_header "Installing Dependencies"

    cd "$PROJECT_ROOT"

    if [ -f "package.json" ]; then
        print_success "Found package.json"

        # Install dependencies
        echo "Installing npm dependencies..."
        npm install

        if [ $? -eq 0 ]; then
            print_success "Dependencies installed successfully"
        else
            print_error "Failed to install dependencies"
            exit 1
        fi
    else
        print_error "package.json not found"
        exit 1
    fi
}

# Setup Git hooks
setup_git_hooks() {
    print_header "Setting Up Git Hooks"

    cd "$PROJECT_ROOT"

    if [ -d ".git" ]; then
        # Create .git/hooks if it doesn't exist
        mkdir -p .git/hooks

        # Create pre-commit hook
        cat > .git/hooks/pre-commit << 'EOF'
#!/bin/bash
# Pre-commit hook for Solo Builder Repository

echo "Running pre-commit checks..."

# Run linting
echo "Running lint..."
npm run lint || {
    echo "Linting failed. Please fix the issues before committing."
    exit 1
}

# Run type checking
echo "Running type check..."
npm run type-check || {
    echo "Type checking failed. Please fix the issues before committing."
    exit 1
}

# Run tests
echo "Running tests..."
npm test || {
    echo "Tests failed. Please fix the issues before committing."
    exit 1
}

echo "Pre-commit checks passed!"
exit 0
EOF

        # Make hooks executable
        chmod +x .git/hooks/pre-commit

        print_success "Git hooks installed"
    else
        print_warning "Not a git repository. Skipping git hooks setup."
    fi
}

# Create environment file
create_env_file() {
    print_header "Creating Environment Configuration"

    ENV_FILE="$PROJECT_ROOT/.env"

    if [ ! -f "$ENV_FILE" ]; then
        cat > "$ENV_FILE" << 'EOF'
# Application Configuration
APP_ENV=development
APP_PORT=3000
APP_HOST=0.0.0.0
APP_NAME=solo-builder-repo

# Logging Configuration
LOG_LEVEL=info
LOG_FORMAT=pretty

# Feature Flags
FEATURES_ANALYTICS=false
FEATURES_EXPERIMENTAL=false
FEATURES_CACHE=true

# Validation Configuration
VALIDATION_STRICT=false
VALIDATION_COERCE=true

# Processing Configuration
PROCESSING_CONCURRENCY=5
PROCESSING_TIMEOUT=30000
PROCESSING_RETRY_ATTEMPTS=3
PROCESSING_RETRY_DELAY=1000

# Cache Configuration
CACHE_ENABLED=true
CACHE_TTL=300
CACHE_MAX_SIZE=1000
CACHE_PROVIDER=memory

# Security Configuration (Development)
CORS_ENABLED=false
RATE_LIMIT_ENABLED=false
EOF

        print_success "Created .env file with default configuration"
        print_warning "Please update the .env file with your production values"
    else
        print_success ".env file already exists"
    fi
}

# Verify TypeScript setup
verify_typescript() {
    print_header "Verifying TypeScript Configuration"

    cd "$PROJECT_ROOT"

    if [ -f "tsconfig.json" ]; then
        print_success "tsconfig.json found"

        # Check TypeScript version
        if npx tsc --version &> /dev/null; then
            TS_VERSION=$(npx tsc --version)
            print_success "TypeScript: $TS_VERSION"
        fi
    else
        print_warning "tsconfig.json not found"
    fi
}

# Run initial build
initial_build() {
    print_header "Running Initial Build"

    cd "$PROJECT_ROOT"

    echo "Building project..."
    npm run build 2>&1 | head -20

    if [ ${PIPESTATUS[0]} -eq 0 ]; then
        print_success "Build completed successfully"
    else
        print_warning "Build completed with warnings (this may be normal for initial setup)"
    fi
}

# Display next steps
display_next_steps() {
    print_header "Setup Complete!"

    echo "
${GREEN}===========================================
Next Steps
===========================================${NC}

1. Update your .env file with production values:
   ${YELLOW}vim .env${NC}

2. Start the development server:
   ${YELLOW}npm run dev${NC}

3. Run tests:
   ${YELLOW}npm test${NC}

4. Build for production:
   ${YELLOW}npm run build${NC}

5. View documentation:
   ${YELLOW}open docs/index.html${NC} (after generation)

Available Commands:
------------------
npm run dev        - Start development server
npm run build      - Build for production
npm run test       - Run tests
npm run lint       - Run linting
npm run format     - Format code
npm run validate   - Run full validation

For more information, see README.md and docs/
"
}

# Main execution
main() {
    echo ""
    echo -e "${BLUE}╔═══════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║   Solo Builder Repository Setup          ║${NC}"
    echo -e "${BLUE}║   Initializing development environment   ║${NC}"
    echo -e "${BLUE}╚═══════════════════════════════════════════╝${NC}"
    echo ""

    check_prerequisites
    create_directories
    install_dependencies
    setup_git_hooks
    create_env_file
    verify_typescript
    initial_build
    display_next_steps
}

# Run main function
main "$@"
