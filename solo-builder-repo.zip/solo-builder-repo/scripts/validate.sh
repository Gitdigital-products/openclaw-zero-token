#!/bin/bash

# =============================================================================
# Validation Script for Solo Builder Repository
# =============================================================================
# This script runs comprehensive validation checks including linting,
# type checking, testing, and documentation verification.

set -e  # Exit on any error
set -u  # Exit on undefined variable
set -o pipefail  # Exit on pipe failure

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"

# Validation tracking
VALIDATION_PASSED=0
VALIDATION_FAILED=0
VALIDATION_WARNINGS=0

# Print functions
print_header() {
    echo -e "\n${BLUE}═══════════════════════════════════════════${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}═══════════════════════════════════════════${NC}\n"
}

print_success() {
    echo -e "${GREEN}✓ PASS${NC} $1"
    ((VALIDATION_PASSED++))
}

print_failure() {
    echo -e "${RED}✗ FAIL${NC} $1"
    ((VALIDATION_FAILED++))
}

print_warning() {
    echo -e "${YELLOW}⚠ WARN${NC} $1"
    ((VALIDATION_WARNINGS++))
}

print_info() {
    echo -e "${CYAN}ℹ INFO${NC} $1"
}

print_section() {
    echo -e "\n${CYAN}───────────────────────────────────────────${NC}"
    echo -e "${CYAN}$1${NC}"
    echo -e "${CYAN}───────────────────────────────────────────${NC}\n"
}

# Change to project root
cd "$PROJECT_ROOT"

# Check for required files
check_required_files() {
    print_header "Checking Required Files"

    REQUIRED_FILES=(
        "package.json"
        "tsconfig.json"
        "README.md"
        "LICENSE"
        "src/index.ts"
        "tests/test_core.ts"
        "tests/test_utils.ts"
    )

    local all_present=true

    for file in "${REQUIRED_FILES[@]}"; do
        if [ -f "$file" ]; then
            print_success "Found: $file"
        else
            print_failure "Missing: $file"
            all_present=false
        fi
    done

    if [ "$all_present" = false ]; then
        print_failure "Some required files are missing"
        return 1
    fi

    print_success "All required files present"
}

# Check for required directories
check_required_dirs() {
    print_header "Checking Required Directories"

    REQUIRED_DIRS=(
        "src"
        "src/core"
        "src/utils"
        "src/templates"
        "tests"
        "scripts"
        "docs"
        ".github/workflows"
    )

    local all_present=true

    for dir in "${REQUIRED_DIRS[@]}"; do
        if [ -d "$dir" ]; then
            print_success "Found: $dir/"
        else
            print_failure "Missing: $dir/"
            all_present=false
        fi
    done

    if [ "$all_present" = false ]; then
        print_failure "Some required directories are missing"
        return 1
    fi

    print_success "All required directories present"
}

# Run ESLint
run_linting() {
    print_header "Running Linting"

    if [ ! -f "package.json" ]; then
        print_warning "Skipping lint: package.json not found"
        return 0
    fi

    # Check if npm dependencies are installed
    if [ ! -d "node_modules" ]; then
        print_warning "Skipping lint: node_modules not found. Run npm install first."
        return 0
    fi

    if ! command -v npm &> /dev/null; then
        print_warning "Skipping lint: npm not available"
        return 0
    fi

    print_info "Running ESLint..."

    if npm run lint 2>&1; then
        print_success "Linting passed"
    else
        print_failure "Linting failed"
        return 1
    fi
}

# Run TypeScript type checking
run_type_check() {
    print_header "Running TypeScript Type Check"

    if [ ! -f "tsconfig.json" ]; then
        print_warning "Skipping type check: tsconfig.json not found"
        return 0
    fi

    # Check if npm dependencies are installed
    if [ ! -d "node_modules" ]; then
        print_warning "Skipping type check: node_modules not found. Run npm install first."
        return 0
    fi

    if ! command -v npx &> /dev/null; then
        print_warning "Skipping type check: npx not available"
        return 0
    fi

    print_info "Running TypeScript compiler..."

    if npx tsc --noEmit --project tsconfig.json 2>&1; then
        print_success "Type checking passed"
    else
        print_failure "Type checking failed"
        return 1
    fi
}

# Run tests
run_tests() {
    print_header "Running Tests"

    if [ ! -f "package.json" ]; then
        print_warning "Skipping tests: package.json not found"
        return 0
    fi

    # Check if npm dependencies are installed
    if [ ! -d "node_modules" ]; then
        print_warning "Skipping tests: node_modules not found. Run npm install first."
        return 0
    fi

    if ! command -v npm &> /dev/null; then
        print_warning "Skipping tests: npm not available"
        return 0
    fi

    print_info "Running test suite..."

    if npm test 2>&1; then
        print_success "Tests passed"
    else
        print_failure "Tests failed"
        return 1
    fi
}

# Check documentation completeness
check_documentation() {
    print_header "Checking Documentation"

    REQUIRED_DOCS=(
        "README.md"
        "CONTRIBUTING.md"
        "CODE_OF_CONDUCT.md"
        "LICENSE"
        "CHANGELOG.md"
        "SECURITY.md"
        "GOVERNANCE.md"
        "docs/overview.md"
        "docs/architecture.md"
        "docs/usage.md"
        "docs/configuration.md"
        "docs/faq.md"
    )

    local all_present=true

    for doc in "${REQUIRED_DOCS[@]}"; do
        if [ -f "$doc" ]; then
            # Check if file has content
            if [ -s "$doc" ]; then
                print_success "Found: $doc"
            else
                print_warning "Empty: $doc"
            fi
        else
            print_failure "Missing: $doc"
            all_present=false
        fi
    done

    # Check README size
    if [ -f "README.md" ]; then
        README_LINES=$(wc -l < "README.md")
        if [ "$README_LINES" -lt 50 ]; then
            print_warning "README.md is very short ($README_LINES lines). Consider adding more detail."
        else
            print_success "README.md has adequate content ($README_LINES lines)"
        fi
    fi

    if [ "$all_present" = false ]; then
        print_failure "Some documentation files are missing"
        return 1
    fi

    print_success "All documentation present"
}

# Check GitHub configuration
check_github_config() {
    print_header "Checking GitHub Configuration"

    GITHUB_FILES=(
        ".github/ISSUE_TEMPLATE/bug_report.md"
        ".github/ISSUE_TEMPLATE/feature_request.md"
        ".github/PULL_REQUEST_TEMPLATE.md"
        ".github/workflows/ci.yml"
    )

    local all_present=true

    for file in "${GITHUB_FILES[@]}"; do
        if [ -f "$file" ]; then
            print_success "Found: $file"
        else
            print_warning "Missing: $file"
            all_present=false
        fi
    done

    if [ "$all_present" = false ]; then
        print_warning "Some GitHub configuration files are missing"
    else
        print_success "All GitHub configuration present"
    fi
}

# Check configuration files
check_configuration() {
    print_header "Checking Configuration Files"

    CONFIG_FILES=(
        ".gitignore"
        ".editorconfig"
        "tsconfig.json"
        "package.json"
    )

    local all_present=true

    for file in "${CONFIG_FILES[@]}"; do
        if [ -f "$file" ]; then
            print_success "Found: $file"
        else
            print_warning "Missing: $file"
            all_present=false
        fi
    done

    # Check .gitignore contents
    if [ -f ".gitignore" ]; then
        if grep -q "node_modules" .gitignore; then
            print_success ".gitignore excludes node_modules"
        else
            print_warning ".gitignore should exclude node_modules"
        fi

        if grep -q "dist" .gitignore; then
            print_success ".gitignore excludes dist"
        else
            print_warning ".gitignore should exclude dist"
        fi
    fi

    if [ "$all_present" = false ]; then
        print_warning "Some configuration files are missing"
    else
        print_success "All configuration files present"
    fi
}

# Check source code structure
check_source_structure() {
    print_header "Checking Source Code Structure"

    # Check core modules
    CORE_FILES=(
        "src/core/engine.ts"
        "src/core/validator.ts"
    )

    for file in "${CORE_FILES[@]}"; do
        if [ -f "$file" ]; then
            print_success "Found: $file"
        else
            print_warning "Missing: $file"
        fi
    done

    # Check utility modules
    UTIL_FILES=(
        "src/utils/logger.ts"
        "src/utils/formatter.ts"
        "src/utils/helpers.ts"
    )

    for file in "${UTIL_FILES[@]}"; do
        if [ -f "$file" ]; then
            print_success "Found: $file"
        else
            print_warning "Missing: $file"
        fi
    done

    # Check template modules
    TEMPLATE_FILES=(
        "src/templates/markdown.ts"
        "src/templates/config.ts"
    )

    for file in "${TEMPLATE_FILES[@]}"; do
        if [ -f "$file" ]; then
            print_success "Found: $file"
        else
            print_warning "Missing: $file"
        fi
    done

    # Check entry points
    if [ -f "src/index.ts" ]; then
        print_success "Found: src/index.ts"

        # Check for exports
        if grep -q "export" "src/index.ts"; then
            print_success "src/index.ts has exports"
        else
            print_warning "src/index.ts has no exports"
        fi
    else
        print_warning "Missing: src/index.ts"
    fi

    if [ -f "src/config.ts" ]; then
        print_success "Found: src/config.ts"
    else
        print_warning "Missing: src/config.ts"
    fi
}

# Check test structure
check_test_structure() {
    print_header "Checking Test Structure"

    TEST_FILES=(
        "tests/test_core.ts"
        "tests/test_utils.ts"
    )

    local has_tests=false

    for file in "${TEST_FILES[@]}"; do
        if [ -f "$file" ]; then
            print_success "Found: $file"
            has_tests=true

            # Check for test content
            if grep -q "describe\|it\|test" "$file"; then
                print_success "$file contains test cases"
            else
                print_warning "$file appears to have no test cases"
            fi
        else
            print_warning "Missing: $file"
        fi
    done

    if [ "$has_tests" = true ]; then
        print_success "Test files present"
    else
        print_warning "No test files found"
    fi
}

# Check scripts
check_scripts() {
    print_header "Checking Scripts"

    SCRIPT_FILES=(
        "scripts/setup.sh"
        "scripts/build.sh"
        "scripts/validate.sh"
    )

    for file in "${SCRIPT_FILES[@]}"; do
        if [ -f "$file" ]; then
            # Check if executable
            if [ -x "$file" ]; then
                print_success "Found (executable): $file"
            else
                print_warning "Found (not executable): $file"
            fi
        else
            print_warning "Missing: $file"
        fi
    done
}

# Run security audit
run_security_audit() {
    print_header "Running Security Audit"

    if [ ! -f "package.json" ]; then
        print_warning "Skipping security audit: package.json not found"
        return 0
    fi

    if [ ! -d "node_modules" ]; then
        print_warning "Skipping security audit: node_modules not found"
        return 0
    fi

    if ! command -v npm &> /dev/null; then
        print_warning "Skipping security audit: npm not available"
        return 0
    fi

    print_info "Running npm audit..."

    # Run audit but don't fail on warnings
    if npm audit --audit-level=high 2>&1; then
        print_success "Security audit passed"
    else
        print_warning "Security audit found issues (see above for details)"
    fi
}

# Check dependency health
check_dependency_health() {
    print_header "Checking Dependency Health"

    if [ ! -f "package.json" ]; then
        print_warning "Skipping dependency check: package.json not found"
        return 0
    fi

    if [ ! -f "package-lock.json" ] && [ ! -f "yarn.lock" ] && [ ! -f "pnpm-lock.yaml" ]; then
        print_warning "No lock file found. Consider running npm install."
    else
        print_success "Lock file present"
    fi

    if command -v npm &> /dev/null; then
        print_info "Checking for outdated dependencies..."

        # Run npm outdated but capture output
        OUTDATED=$(npm outdated 2>&1 || true)

        if [ -n "$OUTDATED" ] && [ "$OUTDATED" != "[]" ]; then
            print_warning "Some dependencies are outdated:"
            echo "$OUTDATED" | head -20
        else
            print_success "Dependencies are up to date"
        fi
    fi
}

# Generate summary
generate_summary() {
    print_header "Validation Summary"

    echo ""
    echo -e "╔═══════════════════════════════════════════╗"
    echo -e "║           Validation Results             ║"
    echo -e "╠═══════════════════════════════════════════╣"
    echo -e "║  ${GREEN}Passed:${NC}    $VALIDATION_PASSED                        ║"
    echo -e "║  ${RED}Failed:${NC}    $VALIDATION_FAILED                        ║"
    echo -e "║  ${YELLOW}Warnings:${NC} $VALIDATION_WARNINGS                        ║"
    echo -e "╚═══════════════════════════════════════════╝"
    echo ""

    if [ "$VALIDATION_FAILED" -gt 0 ]; then
        echo -e "${RED}Validation failed. Please fix the issues above.${NC}"
        return 1
    elif [ "$VALIDATION_WARNINGS" -gt 0 ]; then
        echo -e "${YELLOW}Validation completed with warnings.${NC}"
        echo -e "${YELLOW}Review the warnings above for potential improvements.${NC}"
        return 0
    else
        echo -e "${GREEN}All validation checks passed!${NC}"
        return 0
    fi
}

# Parse command line arguments
parse_args() {
    while [[ $# -gt 0 ]]; do
        case $1 in
            --quick)
                # Skip time-consuming checks
                export SKIP_TESTS=1
                export SKIP_LINT=1
                shift
                ;;
            --files)
                check_required_files
                check_required_dirs
                check_source_structure
                check_test_structure
                check_scripts
                generate_summary
                exit 0
                ;;
            --docs)
                check_documentation
                check_github_config
                generate_summary
                exit 0
                ;;
            --all)
                # Run all checks (default)
                shift
                ;;
            --help)
                echo "Usage: $0 [options]"
                echo ""
                echo "Options:"
                echo "  --quick   Skip time-consuming checks (lint, tests)"
                echo "  --files   Only check file structure"
                echo "  --docs    Only check documentation"
                echo "  --all     Run all checks (default)"
                echo "  --help    Show this help message"
                exit 0
                ;;
            *)
                print_error "Unknown option: $1"
                exit 1
                ;;
        esac
    done
}

# Main validation function
main() {
    # Parse arguments
    parse_args "$@"

    echo ""
    echo -e "${BLUE}╔═══════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║   Solo Builder Repository Validation    ║${NC}"
    echo -e "${BLUE}║   Running comprehensive checks...         ║${NC}"
    echo -e "${BLUE}╚═══════════════════════════════════════════╝${NC}"
    echo ""

    # Run all validation checks
    check_required_files
    check_required_dirs
    check_configuration
    check_source_structure
    check_test_structure
    check_scripts
    check_documentation
    check_github_config
    check_dependency_health

    # Time-consuming checks (skipped with --quick)
    if [ "${SKIP_TESTS:-0}" != "1" ]; then
        run_linting || true
        run_type_check || true
        run_tests || true
    else
        print_info "Skipping lint, type check, and tests (--quick mode)"
    fi

    run_security_audit || true

    # Generate summary
    generate_summary
}

# Run main function
main "$@"
