# Contributor Covenant Code of Conduct

## Our Pledge

We as members, contributors, and leaders pledge to make participation in our community a harassment-free experience for everyone, regardless of age, body size, visible or invisible disability, ethnicity, sex characteristics, gender identity and expression, level of experience, education, socio-economic status, nationality, personal appearance, race, religion, or sexual identity and orientation.

We pledge to act and interact in ways that contribute to an open, welcoming, diverse, inclusive, and healthy community. Our community is built on mutual respect, constructive dialogue, and a shared commitment to excellence in software development.

The solo builder journey can be both rewarding and challenging. By fostering a supportive community, we help each other grow, learn, and achieve more than any of us could accomplish alone. This Code of Conduct reflects the values we share and the environment we strive to create together.

## Our Standards

Examples of behavior that contributes to a positive environment for our community include demonstrating empathy and kindness toward other people, being respectful of differing opinions, viewpoints, and experiences, giving and gracefully accepting constructive feedback, accepting responsibility and apologizing to those affected by our mistakes, and focusing on what is best not just for us as individuals, but for the overall community.

Examples of unacceptable behavior include the use of sexualized language or imagery and sexual attention or advances of any kind, trolling, insulting or derogatory comments, and personal or political attacks, public or private harassment, publishing others' private information, such as a physical or email address, without their explicit consent, and other conduct which could reasonably be considered inappropriate in a professional setting.

Our community is a space for professional collaboration and learning. While we welcome spirited discussions about technical approaches and architectural decisions, personal attacks and disrespectful behavior undermine the collaborative spirit that makes open-source development rewarding. We expect all participants to maintain professional boundaries and focus discussions on ideas, not individuals.

## Enforcement Responsibilities

Community leaders are responsible for clarifying and enforcing our standards of acceptable behavior and will take appropriate and fair corrective action in response to any behavior that they deem inappropriate, threatening, offensive, or harmful.

Community leaders have the right and responsibility to remove, edit, or reject comments, commits, code, wiki edits, issues, and other contributions that are not aligned to this Code of Conduct, and will communicate reasons for moderation decisions when appropriate.

When enforcing this Code of Conduct, community leaders will consider the context and severity of the situation. First-time violations may receive warnings and guidance, while repeated or severe violations may result in temporary or permanent exclusion from community participation.

## Scope

This Code of Conduct applies within all community spaces and also applies when an individual is officially representing the community in public spaces. Examples of representing our community include using an official e-mail address, posting via an official social media account, or acting as an appointed representative at an online or offline event.

Representation of the community extends beyond official roles. How you conduct yourself in any public forum discussing this project reflects on the entire community. Even in heated technical debates, we expect participants to maintain respect for each other and the community as a whole.

## Enforcement

Instances of abusive, harassing, or otherwise unacceptable behavior may be reported to the community leaders responsible for enforcement. All complaints will be reviewed and investigated promptly and fairly.

The enforcement team is committed to handling reports with discretion and confidentiality. Information about reporters will be kept confidential except where necessary to investigate and resolve the issue. In some cases, it may be necessary to publicly acknowledge that an enforcement action occurred while protecting the privacy of individuals involved.

All community leaders are obligated to respect the privacy and security of any incident reporter. Retaliation against individuals who report violations or provide information during an investigation is strictly prohibited and will result in further enforcement action.

## Enforcement Guidelines

Community leaders will follow these Community Impact Guidelines in determining the consequences for any action they deem in violation of this Code of Conduct:

### Correction

**Community Impact**: Use of inappropriate language or other behavior deemed unprofessional or unwelcome in the community.

**Consequence**: A private, written warning from community leaders, providing clarity around the nature of the violation and an explanation of why the behavior was inappropriate. A public apology may be requested from the violator.

### Warning

**Community Impact**: A violation through a single incident or series of actions.

**Consequence**: A warning with consequences for continued behavior. No interaction with the people involved, including unsolicited interaction with those enforcing the Code of Conduct, for a specified period of time. This includes avoiding interactions in community spaces as well as external channels like social media. Violating these terms may lead to a temporary or permanent ban.

### Temporary Ban

**Community Impact**: A serious violation of community standards, including sustained inappropriate behavior.

**Consequence**: A temporary ban from any sort of interaction or public communication with the community for a specified period of time. No public or private interaction with the people involved, including unsolicited interaction with those enforcing the Code of Conduct, is allowed during this period. Violating these terms may lead to a permanent ban.

### Permanent Ban

**Community Impact**: Demonstrating a pattern of violation of community standards, including sustained inappropriate behavior, harassment of an individual, or aggression toward or disparagement of classes of individuals.

**Consequence**: A permanent ban from any sort of public interaction within the community. This includes all community spaces, official communication channels, and any other means of public communication associated with the project.

## Attribution

This Code of Conduct is adapted from the Contributor Covenant, version 2.0, available at https://www.contributor-covenant.org/version/2/0/code_of_conduct.html.

Community Impact Guidelines were inspired by Mozilla's code of conduct enforcement ladder. The Contributor Covenant was created by Coraline Ada Ehmke in 2014 and is maintained by Contributor Covenant, a nonprofit organization. It isadopted by many communities around the world.

## Additional Context

This Code of Conduct exists because we believe that the solo builder community should be a place where everyone feels safe to share their ideas, ask questions, and grow as developers. The open-source community thrives when diverse perspectives come together to solve problems collaboratively.

We recognize that solo builders often work in isolation and may not have the support structures that traditional development teams provide. This community aims to fill that gap by creating connections, sharing knowledge, and supporting each other through the challenges of building software alone.

By participating in this community, you agree to uphold these standards and help create a positive environment for everyone. Your contributions, whether code, documentation, or simply kind words of encouragement, make this community stronger.

## Contact

If you have questions about this Code of Conduct or need to report a violation, please contact the community administrators through the appropriate channels. All reports are taken seriously and will be handled promptly and with discretion.

For urgent matters involving immediate safety concerns, please reach out through the appropriate emergency channels as indicated in the repository's security documentation.

We are committed to making this community welcoming and productive for all solo builders. Thank you for being part of our community and for helping us maintain these standards.
