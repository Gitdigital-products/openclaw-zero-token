<!--- Thank you for contributing! Please fill out this template completely for the best review experience -->

## Description

<!--
  Briefly describe the changes in this pull request.
  What does this PR change? Why?
  Example: "Adds password reset functionality with email verification"
-->

Provide a clear, concise description of what this pull request does. Explain the motivation for the changes and what problem they solve. This helps reviewers understand the context of your changes.

## Type of Change

<!-- Check all that apply -->

- [ ] Bug fix (non-breaking change that fixes an issue)
- [ ] New feature (non-breaking change that adds functionality)
- [ ] Breaking change (fix or feature that would cause existing functionality to change)
- [ ] Documentation update (no code changes)
- [ ] Code refactoring (no functional changes)
- [ ] Performance improvement
- [ ] Test coverage improvement
- [ ] Build/CI update
- [ ] Dependency update

## Testing

<!-- Describe the testing you performed -->

Please describe the tests you added or modified. Explain what scenarios are covered and why these tests are important.

### Test Results

```
<!-- Paste test output here -->
```

### Manual Testing

<!-- If you performed manual testing, describe what you did -->

| Scenario | Steps | Expected | Actual | Pass |
|----------|-------|----------|--------|------|
| | | | | |
| | | | | |

## Checklist

<!-- Ensure all items are checked before submitting -->

- [ ] My code follows the style guidelines of this project
- [ ] I have performed a self-review of my code
- [ ] I have commented my code, particularly in hard-to-understand areas
- [ ] I have made corresponding changes to the documentation
- [ ] My changes generate no new warnings
- [ ] I have added tests that prove my fix is effective or that my feature works
- [ ] New and existing unit tests pass locally with my changes
- [ ] Any dependent changes have been merged and published

## Breaking Changes

<!-- If this PR contains breaking changes, describe them here -->

- [ ] Yes, this PR contains breaking changes
- [ ] No, this PR does not contain breaking changes

If yes, describe the breaking changes and provide migration instructions:

### Breaking Change Description

<!-- Describe what breaks and why -->

### Migration Instructions

<!-- Step-by-step instructions for users to migrate -->

## Screenshots/Recordings

<!-- Include before/after screenshots or recordings if applicable -->

| Before | After |
|--------|-------|
| | |
| | |

## Related Issues

<!-- Link issues this PR addresses or is related to -->

- Closes #<!-- issue number -->
- Fixes #<!-- issue number -->
- Related to #<!-- issue number -->
- See also #<!-- issue number -->

## Additional Context

<!-- Provide any additional context that reviewers should know -->

Include any other relevant information about this pull request, such as:
- Known limitations
- Future considerations
- Dependencies
- Alternative approaches considered

## Commit History

<!-- List the commits in this PR -->

| Commit | Description |
|--------|-------------|
| | |

---

**Reviewer Notes**

<!-- For maintainers: notes to reviewers about this PR -->

---

Thank you for contributing to the Solo Builder Repository! Your effort helps make this project better for everyone.
