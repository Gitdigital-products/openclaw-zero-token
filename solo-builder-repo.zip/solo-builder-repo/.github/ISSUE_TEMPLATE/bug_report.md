<!--- Provide a general summary of the issue in the Title above -->

## Description

<!--
  Describe the issue in detail. Include:
  - What you were trying to accomplish
  - What you expected to happen
  - What actually happened
  - Steps to reproduce the issue
-->

Please describe the bug you encountered. Be specific about what you were doing when the bug occurred and what you expected to happen instead. The more detail you provide, the easier it will be for maintainers to understand and fix the issue.

## Steps to Reproduce

<!--
  Numbered steps to reproduce the bug:
  1. Go to '...'
  2. Run '....'
  3. See error '....'
-->

Provide clear, numbered steps that anyone can follow to reproduce the issue. Include any commands, configurations, or data that were in use when the bug occurred.

## Expected Behavior

<!--
  What should happen instead of the bug?
-->

Describe what you expected to happen. This helps maintainers understand whether this is truly a bug or an unintended behavior that should be changed.

## Actual Behavior

<!--
  What actually happened? Include any error messages, logs, or screenshots.
-->

Describe what actually happened. Include any error messages, stack traces, or unexpected output. If possible, include screenshots that illustrate the issue.

## Environment

Please provide information about your development environment:

| Component | Version |
|-----------|---------|
| Node.js | <!-- Run `node --version` --> |
| npm | <!-- Run `npm --version` --> |
| Operating System | <!-- e.g., macOS 14.0, Ubuntu 22.04, Windows 11 --> |
| Project Version | <!-- Run `npm list` or check package.json --> |

## Configuration

<!--
  Include your configuration files if relevant:
  - package.json relevant sections
  - tsconfig.json
  - .env files (remove sensitive values)
  - Any custom configuration
-->

Provide relevant configuration files. Remove any sensitive information like passwords, API keys, or tokens before submitting.

```json
// Your relevant configuration
```

## Code Snippet

<!--
  Include a minimal code snippet that reproduces the issue. The smaller and more focused, the better.
-->

```typescript
// Your code that causes the issue
```

## Error Output

<!--
  Paste the full error output, including stack traces.
-->

```
Paste error output here
```

## Additional Context

<!--
  Add any other context about the problem here, such as:
  - Related issues or pull requests
  - Browser/device information if applicable
  - Whether this is a regression
  - Any workarounds you've tried
-->

Provide any additional information that might help maintainers understand the issue. This could include whether this is a regression, what you have already tried to fix it, or any relevant context.

## Classification

<!-- Check the boxes that apply -->

- [ ] This is a security vulnerability (Please see our [Security Policy](SECURITY.md))
- [ ] This is a new issue
- [ ] This is an existing issue that recently got worse
- [ ] This is a regression (worked in a previous version)

## Related Issues

<!--
  Link any related issues using keywords:
  Fixes #123
  Related to #456
  See also #789
-->

Link any related issues or pull requests that might be relevant to this bug report.

---

**Thank you for reporting this issue!** Your detailed report helps us fix bugs faster and improve the project for everyone.
