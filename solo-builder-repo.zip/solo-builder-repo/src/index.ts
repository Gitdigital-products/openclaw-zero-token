/**
 * Solo Builder Repository
 * 
 * A production-ready repository template for solo builders.
 * This is the main entry point for the application.
 */

import { config, loadConfig } from './config';
import { Engine } from './core/engine';
import { Logger } from './utils/logger';
import { validateEnvironment } from './utils/helpers';

/**
 * Application class that orchestrates the main functionality.
 * Handles initialization, processing, and cleanup.
 */
export class Application {
  private logger: Logger;
  private engine: Engine;
  private initialized: boolean = false;

  /**
   * Creates a new Application instance.
   * @param options - Optional configuration options
   */
  constructor(options?: Partial<ApplicationOptions>) {
    this.logger = new Logger({
      level: options?.logLevel ?? config.logging.level,
      format: options?.logFormat ?? config.logging.format,
    });
    this.engine = new Engine(this.logger, {
      concurrency: options?.concurrency ?? config.processing.concurrency,
      timeout: options?.timeout ?? config.processing.timeout,
    });
  }

  /**
   * Initializes the application and all its components.
   * Must be called before any other operations.
   * @returns Promise that resolves when initialization is complete
   */
  async initialize(): Promise<void> {
    if (this.initialized) {
      this.logger.warn('Application already initialized');
      return;
    }

    this.logger.info('Initializing application', {
      environment: config.app.environment,
      version: config.app.version,
    });

    try {
      // Validate environment
      validateEnvironment();
      
      // Initialize components
      await this.engine.initialize();
      
      this.initialized = true;
      this.logger.info('Application initialized successfully');
    } catch (error) {
      this.logger.error('Failed to initialize application', {
        error: error instanceof Error ? error.message : String(error),
      });
      throw error;
    }
  }

  /**
   * Runs the main application processing.
   * @param input - The input data to process
   * @returns Promise that resolves with the processing result
   */
  async run(input: ProcessInput): Promise<ProcessResult> {
    if (!this.initialized) {
      throw new Error('Application not initialized. Call initialize() first.');
    }

    this.logger.info('Starting processing', {
      inputType: input.type,
      itemCount: input.items?.length ?? 0,
    });

    const startTime = Date.now();

    try {
      const result = await this.engine.process(input);
      
      const duration = Date.now() - startTime;
      this.logger.info('Processing completed', {
        duration,
        successCount: result.successCount,
        failureCount: result.failureCount,
      });

      return result;
    } catch (error) {
      const duration = Date.now() - startTime;
      this.logger.error('Processing failed', {
        duration,
        error: error instanceof Error ? error.message : String(error),
      });
      throw error;
    }
  }

  /**
   * Gracefully shuts down the application.
   * @returns Promise that resolves when shutdown is complete
   */
  async shutdown(): Promise<void> {
    this.logger.info('Shutting down application');

    try {
      await this.engine.shutdown();
      this.logger.info('Application shutdown complete');
    } catch (error) {
      this.logger.error('Error during shutdown', {
        error: error instanceof Error ? error.message : String(error),
      });
      throw error;
    }
  }

  /**
   * Gets the current health status of the application.
   * @returns Health status object
   */
  getHealth(): HealthStatus {
    return {
      status: this.initialized ? 'healthy' : 'unhealthy',
      initialized: this.initialized,
      uptime: process.uptime(),
      timestamp: new Date().toISOString(),
    };
  }
}

/**
 * Options for configuring the Application.
 */
export interface ApplicationOptions {
  logLevel: LogLevel;
  logFormat: LogFormat;
  concurrency: number;
  timeout: number;
}

/**
 * Input data for processing.
 */
export interface ProcessInput {
  type: string;
  items?: unknown[];
  options?: Record<string, unknown>;
}

/**
 * Result of processing operation.
 */
export interface ProcessResult {
  successCount: number;
  failureCount: number;
  results: unknown[];
  errors: ProcessingError[];
  duration: number;
}

/**
 * Processing error details.
 */
export interface ProcessingError {
  item: unknown;
  error: string;
  timestamp: string;
}

/**
 * Application health status.
 */
export interface HealthStatus {
  status: 'healthy' | 'unhealthy' | 'degraded';
  initialized: boolean;
  uptime: number;
  timestamp: string;
}

/**
 * Log level type.
 */
export type LogLevel = 'trace' | 'debug' | 'info' | 'warn' | 'error';

/**
 * Log format type.
 */
export type LogFormat = 'json' | 'pretty' | 'simple';

// Type definitions for external usage
export { config, loadConfig } from './config';
export { Logger } from './utils/logger';
export { Engine } from './core/engine';
export { Validator } from './core/validator';
export * from './utils/helpers';
export * from './templates/markdown';
export * from './templates/config';

// Main execution when run directly
if (require.main === module) {
  const app = new Application();

  // Handle graceful shutdown
  process.on('SIGINT', async () => {
    console.log('\nReceived SIGINT, shutting down gracefully...');
    try {
      await app.shutdown();
      process.exit(0);
    } catch (error) {
      console.error('Error during shutdown:', error);
      process.exit(1);
    }
  });

  process.on('SIGTERM', async () => {
    console.log('\nReceived SIGTERM, shutting down gracefully...');
    try {
      await app.shutdown();
      process.exit(0);
    } catch (error) {
      console.error('Error during shutdown:', error);
      process.exit(1);
    }
  });

  // Run the application
  app.initialize()
    .then(() => {
      console.log('Application initialized successfully');
      return app.run({ type: 'default' });
    })
    .then((result) => {
      console.log('Processing complete:', result);
      return app.shutdown();
    })
    .then(() => {
      console.log('Application shutdown complete');
    })
    .catch((error) => {
      console.error('Application error:', error);
      process.exit(1);
    });
}
