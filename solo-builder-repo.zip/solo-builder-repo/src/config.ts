/**
 * Configuration Management Module
 * 
 * Handles loading, validation, and access to application configuration.
 * Supports multiple configuration sources with defined precedence.
 */

import * as fs from 'fs';
import * as path from 'path';
import * as yaml from 'yaml';

/**
 * Application configuration interface.
 */
export interface AppConfig {
  app: AppSettings;
  logging: LoggingSettings;
  features: FeatureSettings;
  validation: ValidationSettings;
  processing: ProcessingSettings;
  database?: DatabaseSettings;
  cache: CacheSettings;
  security: SecuritySettings;
}

/**
 * Application settings.
 */
export interface AppSettings {
  name: string;
  version: string;
  port: number;
  host: string;
  environment: 'development' | 'production' | 'test';
}

/**
 * Logging settings.
 */
export interface LoggingSettings {
  level: 'trace' | 'debug' | 'info' | 'warn' | 'error';
  format: 'json' | 'pretty' | 'simple';
  destinations: ('console' | 'file' | 'syslog')[];
  file?: {
    path: string;
    maxSize: string;
    maxFiles: number;
  };
}

/**
 * Feature flags.
 */
export interface FeatureSettings {
  analytics: boolean;
  experimental: boolean;
  cache: boolean;
}

/**
 * Validation settings.
 */
export interface ValidationSettings {
  strict: boolean;
  coerce: boolean;
}

/**
 * Processing settings.
 */
export interface ProcessingSettings {
  concurrency: number;
  timeout: number;
  retryAttempts: number;
  retryDelay: number;
}

/**
 * Database settings.
 */
export interface DatabaseSettings {
  host: string;
  port: number;
  name: string;
  user: string;
  password: string;
  ssl: boolean;
  pool: {
    min: number;
    max: number;
  };
}

/**
 * Cache settings.
 */
export interface CacheSettings {
  enabled: boolean;
  ttl: number;
  maxSize: number;
  provider: 'memory' | 'redis';
}

/**
 * Security settings.
 */
export interface SecuritySettings {
  cors: {
    enabled: boolean;
    origins: string[];
    methods: string[];
  };
  rateLimit: {
    enabled: boolean;
    windowMs: number;
    maxRequests: number;
  };
  hsts: {
    enabled: boolean;
    maxAge: number;
  };
}

/**
 * Default configuration values.
 */
const DEFAULT_CONFIG: AppConfig = {
  app: {
    name: 'solo-builder-repo',
    version: '1.0.0',
    port: parseInt(process.env.APP_PORT || '3000', 10),
    host: process.env.APP_HOST || '0.0.0.0',
    environment: (process.env.APP_ENV as AppSettings['environment']) || 'development',
  },
  logging: {
    level: (process.env.LOG_LEVEL as LoggingSettings['level']) || 'info',
    format: (process.env.LOG_FORMAT as LoggingSettings['format']) || 'pretty',
    destinations: ['console'],
  },
  features: {
    analytics: process.env.FEATURES_ANALYTICS !== 'false',
    experimental: process.env.FEATURES_EXPERIMENTAL === 'true',
    cache: process.env.FEATURES_CACHE !== 'false',
  },
  validation: {
    strict: process.env.VALIDATION_STRICT !== 'false',
    coerce: process.env.VALIDATION_COERCE !== 'false',
  },
  processing: {
    concurrency: parseInt(process.env.PROCESSING_CONCURRENCY || '5', 10),
    timeout: parseInt(process.env.PROCESSING_TIMEOUT || '30000', 10),
    retryAttempts: parseInt(process.env.PROCESSING_RETRY_ATTEMPTS || '3', 10),
    retryDelay: parseInt(process.env.PROCESSING_RETRY_DELAY || '1000', 10),
  },
  cache: {
    enabled: process.env.CACHE_ENABLED !== 'false',
    ttl: parseInt(process.env.CACHE_TTL || '300', 10),
    maxSize: parseInt(process.env.CACHE_MAX_SIZE || '1000', 10),
    provider: (process.env.CACHE_PROVIDER as CacheSettings['provider']) || 'memory',
  },
  security: {
    cors: {
      enabled: process.env.CORS_ENABLED === 'true',
      origins: process.env.CORS_ORIGINS ? process.env.CORS_ORIGINS.split(',') : ['*'],
      methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'],
    },
    rateLimit: {
      enabled: process.env.RATE_LIMIT_ENABLED === 'true',
      windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS || '900000', 10),
      maxRequests: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS || '100', 10),
    },
    hsts: {
      enabled: process.env.HSTS_ENABLED !== 'false',
      maxAge: parseInt(process.env.HSTS_MAX_AGE || '31536000', 10),
    },
  },
};

/**
 * Configuration file paths to search for.
 */
const CONFIG_PATHS = [
  path.join(process.cwd(), 'config.json'),
  path.join(process.cwd(), 'config.yaml'),
  path.join(process.cwd(), 'config', 'config.json'),
  path.join(process.cwd(), 'config', 'config.yaml'),
  path.join(process.env.HOME || '', '.config', 'solo-builder', 'config.json'),
];

/**
 * Loads configuration from files.
 * @returns The loaded configuration object
 */
function loadConfigFromFile(): Partial<AppConfig> {
  for (const configPath of CONFIG_PATHS) {
    if (fs.existsSync(configPath)) {
      try {
        const content = fs.readFileSync(configPath, 'utf-8');
        const ext = path.extname(configPath).toLowerCase();

        if (ext === '.yaml' || ext === '.yml') {
          return yaml.parse(content);
        } else {
          return JSON.parse(content);
        }
      } catch (error) {
        console.warn(`Failed to load config from ${configPath}:`, error);
      }
    }
  }

  return {};
}

/**
 * Deep merge two objects.
 * @param target - The target object
 * @param source - The source object
 * @returns The merged object
 */
function deepMerge<T extends Record<string, unknown>>(target: T, source: Partial<T>): T {
  const result = { ...target };

  for (const key in source) {
    if (Object.prototype.hasOwnProperty.call(source, key)) {
      const sourceValue = source[key];
      const targetValue = target[key];

      if (
        sourceValue !== undefined &&
        typeof sourceValue === 'object' &&
        !Array.isArray(sourceValue) &&
        targetValue !== undefined &&
        typeof targetValue === 'object' &&
        !Array.isArray(targetValue)
      ) {
        (result as Record<string, unknown>)[key] = deepMerge(
          targetValue as Record<string, unknown>,
          sourceValue as Record<string, unknown>
        );
      } else if (sourceValue !== undefined) {
        (result as Record<string, unknown>)[key] = sourceValue as never;
      }
    }
  }

  return result;
}

/**
 * Loads and merges configuration from all sources.
 * @returns The complete configuration object
 */
export function loadConfig(): AppConfig {
  // Start with defaults
  let config = { ...DEFAULT_CONFIG };

  // Merge with file configuration
  const fileConfig = loadConfigFromFile();
  config = deepMerge(config, fileConfig);

  // Environment variables are already in defaults, but we can override specific values
  if (process.env.APP_NAME) {
    config.app.name = process.env.APP_NAME;
  }
  if (process.env.APP_VERSION) {
    config.app.version = process.env.APP_VERSION;
  }

  return config;
}

/**
 * Validates the configuration.
 * @param cfg - The configuration to validate
 * @throws Error if validation fails
 */
export function validateConfig(cfg: AppConfig): void {
  const errors: string[] = [];

  // Validate app settings
  if (!cfg.app.name) {
    errors.push('app.name is required');
  }
  if (cfg.app.port < 1 || cfg.app.port > 65535) {
    errors.push('app.port must be between 1 and 65535');
  }
  if (!['development', 'production', 'test'].includes(cfg.app.environment)) {
    errors.push('app.environment must be development, production, or test');
  }

  // Validate logging settings
  if (!['trace', 'debug', 'info', 'warn', 'error'].includes(cfg.logging.level)) {
    errors.push('logging.level must be trace, debug, info, warn, or error');
  }
  if (!['json', 'pretty', 'simple'].includes(cfg.logging.format)) {
    errors.push('logging.format must be json, pretty, or simple');
  }

  // Validate processing settings
  if (cfg.processing.concurrency < 1) {
    errors.push('processing.concurrency must be at least 1');
  }
  if (cfg.processing.timeout < 0) {
    errors.push('processing.timeout must be non-negative');
  }
  if (cfg.processing.retryAttempts < 0) {
    errors.push('processing.retryAttempts must be non-negative');
  }

  // Validate cache settings
  if (cfg.cache.ttl < 0) {
    errors.push('cache.ttl must be non-negative');
  }
  if (cfg.cache.maxSize < 1) {
    errors.push('cache.maxSize must be at least 1');
  }

  if (errors.length > 0) {
    throw new Error(`Configuration validation failed:\n${errors.join('\n')}`);
  }
}

// Export the singleton configuration instance
export const config = loadConfig();

// Validate on module load
try {
  validateConfig(config);
} catch (error) {
  console.error('Configuration validation failed:', error);
  if (config.app.environment === 'production') {
    process.exit(1);
  }
}

/**
 * Reloads configuration from sources.
 * Useful for hot reloading in development.
 * @returns The reloaded configuration
 */
export function reloadConfig(): AppConfig {
  // Clear any cached file contents would go here
  // For now, simply reload
  const newConfig = loadConfig();
  validateConfig(newConfig);
  
  // Update the exported config
  Object.assign(config, newConfig);
  
  return config;
}
