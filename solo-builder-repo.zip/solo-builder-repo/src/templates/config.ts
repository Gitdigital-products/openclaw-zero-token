/**
 * Configuration Template Module
 * 
 * Provides utilities for generating configuration files from templates.
 * Supports JSON, YAML, and environment variable formats.
 */

import * as yaml from 'yaml';
import { camelToSnake, snakeToCamel } from '../utils/formatter';

/**
 * Configuration template options.
 */
export interface ConfigTemplateOptions {
  format: 'json' | 'yaml' | 'env';
  includeComments?: boolean;
  prettyPrint?: boolean;
  transformKeys?: 'camel' | 'snake' | 'none';
}

/**
 * Default configuration template.
 */
export interface DefaultConfig {
  app?: {
    name?: string;
    version?: string;
    port?: number;
    host?: string;
    environment?: string;
  };
  logging?: {
    level?: string;
    format?: string;
    destinations?: string[];
    file?: {
      path?: string;
      maxSize?: string;
      maxFiles?: number;
    };
  };
  features?: {
    analytics?: boolean;
    experimental?: boolean;
    cache?: boolean;
  };
  validation?: {
    strict?: boolean;
    coerce?: boolean;
  };
  processing?: {
    concurrency?: number;
    timeout?: number;
    retryAttempts?: number;
    retryDelay?: number;
  };
  database?: {
    host?: string;
    port?: number;
    name?: string;
    user?: string;
    password?: string;
    ssl?: boolean;
    pool?: {
      min?: number;
      max?: number;
    };
  };
  cache?: {
    enabled?: boolean;
    ttl?: number;
    maxSize?: number;
    provider?: string;
  };
  security?: {
    cors?: {
      enabled?: boolean;
      origins?: string[];
      methods?: string[];
    };
    rateLimit?: {
      enabled?: boolean;
      windowMs?: number;
      maxRequests?: number;
    };
    hsts?: {
      enabled?: boolean;
      maxAge?: number;
    };
  };
}

/**
 * Generates a configuration file from options.
 * @param config - Configuration object
 * @param options - Template options
 * @returns Formatted configuration string
 */
export function generateConfig(
  config: DefaultConfig,
  options: ConfigTemplateOptions = { format: 'json', prettyPrint: true }
): string {
  const { format, includeComments = true, prettyPrint = true, transformKeys = 'none' } = options;

  // Transform keys if requested
  let transformedConfig = config;
  if (transformKeys === 'camel') {
    transformedConfig = transformObjectKeys(config, snakeToCamel) as DefaultConfig;
  } else if (transformKeys === 'snake') {
    transformedConfig = transformObjectKeys(config, camelToSnake) as DefaultConfig;
  }

  switch (format) {
    case 'json':
      return generateJsonConfig(transformedConfig, { prettyPrint, includeComments });
    case 'yaml':
      return generateYamlConfig(transformedConfig, { prettyPrint });
    case 'env':
      return generateEnvConfig(transformedConfig);
    default:
      return generateJsonConfig(transformedConfig, { prettyPrint, includeComments });
  }
}

/**
 * Generates a JSON configuration file.
 * @param config - Configuration object
 * @param options - Generation options
 * @returns JSON string
 */
function generateJsonConfig(
  config: DefaultConfig,
  options: { prettyPrint?: boolean; includeComments?: boolean }
): string {
  // Add comments via JSON5-like approach or just output clean JSON
  if (options.prettyPrint) {
    return JSON.stringify(config, null, 2);
  }
  return JSON.stringify(config);
}

/**
 * Generates a YAML configuration file.
 * @param config - Configuration object
 * @param options - Generation options
 * @returns YAML string
 */
function generateYamlConfig(
  config: DefaultConfig,
  options: { prettyPrint?: boolean }
): string {
  return yaml.stringify(config, {
    indent: options.prettyPrint ? 2 : 0,
  });
}

/**
 * Generates an environment variable configuration.
 * @param config - Configuration object
 * @returns Environment variable string
 */
function generateEnvConfig(config: DefaultConfig): string {
  const lines: string[] = [];
  lines.push('# Generated configuration file');
  lines.push('# Copy this to .env and update values as needed');
  lines.push('');

  // Flatten the configuration to environment variables
  const flatConfig = flattenObject(config, '', lines);

  for (const [key, value] of Object.entries(flatConfig)) {
    const envKey = key.toUpperCase().replace(/\./g, '_');
    if (typeof value === 'boolean') {
      lines.push(`${envKey}=${value ? 'true' : 'false'}`);
    } else if (typeof value === 'string') {
      lines.push(`${envKey}="${value}"`);
    } else {
      lines.push(`${envKey}=${value}`);
    }
  }

  return lines.join('\n');
}

/**
 * Recursively transforms object keys.
 * @param obj - Object to transform
 * @param transform - Transformation function
 * @returns Transformed object
 */
function transformObjectKeys(
  obj: unknown,
  transform: (key: string) => string
): unknown {
  if (obj === null || typeof obj !== 'object') {
    return obj;
  }

  if (Array.isArray(obj)) {
    return obj.map((item) => transformObjectKeys(item, transform));
  }

  const result: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(obj as Record<string, unknown>)) {
    result[transform(key)] = transformObjectKeys(value, transform);
  }
  return result;
}

/**
 * Flattens a nested object to dot-notation keys.
 * @param obj - Object to flatten
 * @param prefix - Key prefix
 * @param lines - Array to collect comments
 * @returns Flattened object
 */
function flattenObject(
  obj: unknown,
  prefix: string,
  lines: string[]
): Record<string, unknown> {
  const result: Record<string, unknown> = {};

  if (obj === null || typeof obj !== 'object') {
    return { [prefix || 'value']: obj };
  }

  if (Array.isArray(obj)) {
    for (let i = 0; i < obj.length; i++) {
      const nested = flattenObject(obj[i], prefix ? `${prefix}_${i}` : String(i), lines);
      Object.assign(result, nested);
    }
    return result;
  }

  for (const [key, value] of Object.entries(obj as Record<string, unknown>)) {
    const newKey = prefix ? `${prefix}.${key}` : key;

    if (value === null || value === undefined) {
      continue;
    }

    if (typeof value === 'object' && !Array.isArray(value)) {
      // Add comment for nested objects
      lines.push(`# ${key} configuration`);
      Object.assign(result, flattenObject(value, newKey, lines));
    } else {
      result[newKey] = value;
    }
  }

  return result;
}

/**
 * Generates a development configuration template.
 * @returns Development configuration string
 */
export function generateDevelopmentConfig(): string {
  return generateConfig({
    app: {
      name: 'my-app',
      version: '1.0.0',
      port: 3000,
      host: '0.0.0.0',
      environment: 'development',
    },
    logging: {
      level: 'debug',
      format: 'pretty',
      destinations: ['console'],
    },
    features: {
      analytics: false,
      experimental: true,
      cache: true,
    },
    validation: {
      strict: false,
      coerce: true,
    },
    processing: {
      concurrency: 5,
      timeout: 30000,
      retryAttempts: 3,
      retryDelay: 1000,
    },
    cache: {
      enabled: true,
      ttl: 60,
      maxSize: 500,
      provider: 'memory',
    },
    security: {
      cors: {
        enabled: false,
        origins: ['http://localhost:3000'],
        methods: ['GET', 'POST', 'PUT', 'DELETE'],
      },
      rateLimit: {
        enabled: false,
        windowMs: 900000,
        maxRequests: 100,
      },
      hsts: {
        enabled: false,
        maxAge: 31536000,
      },
    },
  }, { format: 'json', prettyPrint: true });
}

/**
 * Generates a production configuration template.
 * @returns Production configuration string
 */
export function generateProductionConfig(): string {
  return generateConfig({
    app: {
      name: 'my-app',
      version: '1.0.0',
      port: 8080,
      host: '0.0.0.0',
      environment: 'production',
    },
    logging: {
      level: 'info',
      format: 'json',
      destinations: ['console', 'file'],
      file: {
        path: './logs/app.log',
        maxSize: '10m',
        maxFiles: 5,
      },
    },
    features: {
      analytics: true,
      experimental: false,
      cache: true,
    },
    validation: {
      strict: true,
      coerce: false,
    },
    processing: {
      concurrency: 10,
      timeout: 60000,
      retryAttempts: 5,
      retryDelay: 2000,
    },
    database: {
      host: '${DATABASE_HOST}',
      port: 5432,
      name: '${DATABASE_NAME}',
      user: '${DATABASE_USER}',
      password: '${DATABASE_PASSWORD}',
      ssl: true,
      pool: {
        min: 5,
        max: 20,
      },
    },
    cache: {
      enabled: true,
      ttl: 300,
      maxSize: 10000,
      provider: 'redis',
    },
    security: {
      cors: {
        enabled: true,
        origins: ['https://myapp.com'],
        methods: ['GET', 'POST', 'PUT', 'DELETE'],
      },
      rateLimit: {
        enabled: true,
        windowMs: 900000,
        maxRequests: 100,
      },
      hsts: {
        enabled: true,
        maxAge: 31536000,
      },
    },
  }, { format: 'yaml', prettyPrint: true });
}

/**
 * Generates a test configuration template.
 * @returns Test configuration string
 */
export function generateTestConfig(): string {
  return generateConfig({
    app: {
      name: 'my-app-test',
      version: '1.0.0',
      port: 3001,
      host: '127.0.0.1',
      environment: 'test',
    },
    logging: {
      level: 'error',
      format: 'json',
      destinations: ['console'],
    },
    features: {
      analytics: false,
      experimental: false,
      cache: false,
    },
    validation: {
      strict: true,
      coerce: true,
    },
    processing: {
      concurrency: 2,
      timeout: 5000,
      retryAttempts: 1,
      retryDelay: 100,
    },
    cache: {
      enabled: false,
      ttl: 0,
      maxSize: 0,
      provider: 'memory',
    },
    security: {
      cors: {
        enabled: false,
        origins: [],
        methods: ['GET', 'POST'],
      },
      rateLimit: {
        enabled: false,
        windowMs: 900000,
        maxRequests: 1000,
      },
      hsts: {
        enabled: false,
        maxAge: 0,
      },
    },
  }, { format: 'json', prettyPrint: true });
}

/**
 * Generates a Docker Compose configuration.
 * @returns Docker Compose YAML string
 */
export function generateDockerCompose(): string {
  return `version: '3.8'

services:
  app:
    build: .
    ports:
      - "\${APP_PORT:-3000}:3000"
    environment:
      - NODE_ENV=\${NODE_ENV:-production}
      - DATABASE_HOST=db
      - DATABASE_PORT=5432
      - DATABASE_NAME=\${DATABASE_NAME:-myapp}
      - DATABASE_USER=\${DATABASE_USER:-appuser}
      - DATABASE_PASSWORD=\${DATABASE_PASSWORD}
      - CACHE_PROVIDER=redis
      - REDIS_HOST=redis
    depends_on:
      - db
      - redis
    restart: unless-stopped
    volumes:
      - ./logs:/app/logs

  db:
    image: postgres:15-alpine
    environment:
      - POSTGRES_DB=\${DATABASE_NAME:-myapp}
      - POSTGRES_USER=\${DATABASE_USER:-appuser}
      - POSTGRES_PASSWORD=\${DATABASE_PASSWORD}
    volumes:
      - postgres_data:/var/lib/postgresql/data
    restart: unless-stopped

  redis:
    image: redis:7-alpine
    volumes:
      - redis_data:/data
    restart: unless-stopped

volumes:
  postgres_data:
  redis_data:
`;
}

/**
 * Generates a Kubernetes deployment manifest.
 * @param options - Deployment options
 * @returns Kubernetes manifest YAML
 */
export function generateKubernetesManifest(options: {
  appName: string;
  image: string;
  replicas?: number;
  port?: number;
  memoryLimit?: string;
  cpuLimit?: string;
}): string {
  const {
    appName,
    image,
    replicas = 3,
    port = 3000,
    memoryLimit = '512Mi',
    cpuLimit = '500m',
  } = options;

  return `apiVersion: apps/v1
kind: Deployment
metadata:
  name: ${appName}
  labels:
    app: ${appName}
spec:
  replicas: ${replicas}
  selector:
    matchLabels:
      app: ${appName}
  template:
    metadata:
      labels:
        app: ${appName}
    spec:
      containers:
        - name: ${appName}
          image: ${image}
          ports:
            - containerPort: ${port}
          resources:
            limits:
              memory: ${memoryLimit}
              cpu: ${cpuLimit}
            requests:
              memory: "256Mi"
              cpu: "250m"
          env:
            - name: NODE_ENV
              value: "production"
            - name: PORT
              value: "${port}"
          livenessProbe:
            httpGet:
              path: /health
              port: ${port}
            initialDelaySeconds: 30
            periodSeconds: 10
          readinessProbe:
            httpGet:
              path: /ready
              port: ${port}
            initialDelaySeconds: 5
            periodSeconds: 5
---
apiVersion: v1
kind: Service
metadata:
  name: ${appName}
spec:
  type: ClusterIP
  ports:
    - port: 80
      targetPort: ${port}
  selector:
    app: ${appName}
`;
}

/**
 * Validates configuration against a schema.
 * @param config - Configuration to validate
 * @returns Validation result
 */
export function validateConfigSchema(config: unknown): {
  valid: boolean;
  errors: string[];
} {
  const errors: string[] = [];

  if (typeof config !== 'object' || config === null) {
    errors.push('Configuration must be an object');
    return { valid: false, errors };
  }

  const cfg = config as Record<string, unknown>;

  // Validate app section
  if (cfg.app) {
    if (typeof cfg.app !== 'object') {
      errors.push('app must be an object');
    } else {
      const app = cfg.app as Record<string, unknown>;
      if (app.port !== undefined && typeof app.port !== 'number') {
        errors.push('app.port must be a number');
      }
      if (app.environment !== undefined && !['development', 'production', 'test'].includes(app.environment as string)) {
        errors.push('app.environment must be development, production, or test');
      }
    }
  }

  // Validate logging section
  if (cfg.logging) {
    if (typeof cfg.logging !== 'object') {
      errors.push('logging must be an object');
    } else {
      const logging = cfg.logging as Record<string, unknown>;
      if (logging.level !== undefined && !['trace', 'debug', 'info', 'warn', 'error'].includes(logging.level as string)) {
        errors.push('logging.level must be trace, debug, info, warn, or error');
      }
    }
  }

  return { valid: errors.length === 0, errors };
}
