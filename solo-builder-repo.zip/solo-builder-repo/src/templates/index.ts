/**
 * Templates Module Index
 * 
 * Exports all template generation functions.
 */

// Markdown templates
export {
  renderMarkdown,
  renderChangelogEntry,
  renderApiDoc,
  compileTemplate,
  markdownToHtml,
} from './markdown';

export type {
  MarkdownDocument,
  MarkdownSection,
  MarkdownContent,
  SectionOptions,
  CalloutVariant,
} from './markdown';

// Config templates
export {
  generateConfig,
  generateDevelopmentConfig,
  generateProductionConfig,
  generateTestConfig,
  generateDockerCompose,
  generateKubernetesManifest,
  validateConfigSchema,
} from './config';

export type {
  ConfigTemplateOptions,
  DefaultConfig,
} from './config';
