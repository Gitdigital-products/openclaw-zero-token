/**
 * Markdown Template Module
 * 
 * Provides utilities for generating markdown content from templates.
 * Supports common documentation patterns and custom template rendering.
 */

import { marked } from 'marked';
import { formatDate, capitalize } from '../utils/formatter';

/**
 * Markdown document structure.
 */
export interface MarkdownDocument {
  title?: string;
  description?: string;
  sections?: MarkdownSection[];
  metadata?: Record<string, unknown>;
  footer?: string;
}

/**
 * Markdown section structure.
 */
export interface MarkdownSection {
  heading: string;
  level?: number;
  content: string | MarkdownContent[];
  options?: SectionOptions;
}

/**
 * Section formatting options.
 */
export interface SectionOptions {
  id?: string;
  collapsed?: boolean;
  anchor?: boolean;
}

/**
 * Markdown content types.
 */
export type MarkdownContent = 
  | { type: 'paragraph'; text: string }
  | { type: 'heading'; text: string; level: number }
  | { type: 'code'; code: string; language?: string; caption?: string }
  | { type: 'list'; items: string[]; ordered?: boolean }
  | { type: 'table'; headers: string[]; rows: string[][] }
  | { type: 'blockquote'; text: string; cite?: string }
  | { type: 'link'; text: string; url: string; title?: string }
  | { type: 'image'; alt: string; url: string; title?: string }
  | { type: 'hr' }
  | { type: 'callout'; text: string; variant?: CalloutVariant };

/**
 * Callout variant types.
 */
export type CalloutVariant = 'info' | 'warning' | 'danger' | 'success' | 'tip';

/**
 * Generates a markdown document from a structured definition.
 * @param doc - Document definition
 * @returns Markdown string
 */
export function renderMarkdown(doc: MarkdownDocument): string {
  const lines: string[] = [];

  // Title and description
  if (doc.title) {
    lines.push(`# ${doc.title}`);
    lines.push('');
  }

  if (doc.description) {
    lines.push(doc.description);
    lines.push('');
  }

  // Metadata
  if (doc.metadata) {
    lines.push(renderMetadata(doc.metadata));
    lines.push('');
  }

  // Sections
  if (doc.sections) {
    for (const section of doc.sections) {
      lines.push(...renderSection(section));
      lines.push('');
    }
  }

  // Footer
  if (doc.footer) {
    lines.push('---');
    lines.push('');
    lines.push(doc.footer);
  }

  return lines.join('\n').trim() + '\n';
}

/**
 * Renders metadata as frontmatter.
 * @param metadata - Metadata object
 * @returns Markdown string
 */
function renderMetadata(metadata: Record<string, unknown>): string {
  const lines = ['---'];
  
  for (const [key, value] of Object.entries(metadata)) {
    if (typeof value === 'string') {
      lines.push(`${key}: "${value}"`);
    } else if (typeof value === 'number' || typeof value === 'boolean') {
      lines.push(`${key}: ${value}`);
    } else if (Array.isArray(value)) {
      lines.push(`${key}:`);
      for (const item of value) {
        lines.push(`  - ${item}`);
      }
    } else if (typeof value === 'object' && value !== null) {
      lines.push(`${key}:`);
      const nested = renderObject(value as Record<string, unknown>, 1);
      lines.push(...nested);
    }
  }
  
  lines.push('---');
  return lines.join('\n');
}

/**
 * Renders an object with indentation.
 * @param obj - Object to render
 * @param indent - Indentation level
 * @returns Lines of rendered object
 */
function renderObject(obj: Record<string, unknown>, indent: number): string[] {
  const lines: string[] = [];
  const prefix = '  '.repeat(indent);

  for (const [key, value] of Object.entries(obj)) {
    if (typeof value === 'string') {
      lines.push(`${prefix}${key}: "${value}"`);
    } else if (typeof value === 'number' || typeof value === 'boolean') {
      lines.push(`${prefix}${key}: ${value}`);
    } else if (Array.isArray(value)) {
      lines.push(`${prefix}${key}:`);
      for (const item of value) {
        lines.push(`${prefix}  - ${item}`);
      }
    } else if (typeof value === 'object' && value !== null) {
      lines.push(`${prefix}${key}:`);
      lines.push(...renderObject(value as Record<string, unknown>, indent + 1));
    }
  }

  return lines;
}

/**
 * Renders a section.
 * @param section - Section definition
 * @returns Lines of rendered section
 */
function renderSection(section: MarkdownSection): string[] {
  const lines: string[] = [];
  const level = section.level ?? 2;

  // Heading
  let heading = `${'#'.repeat(level)} ${section.heading}`;
  if (section.options?.id) {
    heading += ` {#${section.options.id}}`;
  }
  lines.push(heading);
  lines.push('');

  // Content
  if (typeof section.content === 'string') {
    lines.push(section.content);
  } else if (Array.isArray(section.content)) {
    for (const item of section.content) {
      lines.push(...renderContent(item));
    }
  }

  return lines;
}

/**
 * Renders content items.
 * @param content - Content item
 * @returns Lines of rendered content
 */
function renderContent(content: MarkdownContent): string[] {
  switch (content.type) {
    case 'paragraph':
      return [content.text, ''];

    case 'heading':
      return [`${'#'.repeat(content.level)} ${content.text}`, ''];

    case 'code':
      return renderCode(content);

    case 'list':
      return renderList(content);

    case 'table':
      return renderTable(content);

    case 'blockquote':
      return renderBlockquote(content);

    case 'link':
      if (content.title) {
        return [`[${content.text}](${content.url} "${content.title}")`, ''];
      }
      return [`[${content.text}](${content.url})`, ''];

    case 'image':
      if (content.title) {
        return [`![${content.alt}](${content.url} "${content.title}")`, ''];
      }
      return [`![${content.alt}](${content.url})`, ''];

    case 'hr':
      return ['---', ''];

    case 'callout':
      return renderCallout(content);

    default:
      return [''];
  }
}

/**
 * Renders code block.
 * @param content - Code content
 * @returns Lines of rendered code
 */
function renderCode(content: { code: string; language?: string; caption?: string }): string[] {
  const lines: string[] = [];

  lines.push(`\`\`\`${content.language ?? ''}`);
  lines.push(content.code);
  lines.push('```');

  if (content.caption) {
    lines.push('');
    lines.push(`*${content.caption}*`);
  }

  lines.push('');
  return lines;
}

/**
 * Renders list.
 * @param content - List content
 * @returns Lines of rendered list
 */
function renderList(content: { items: string[]; ordered?: boolean }): string[] {
  const lines: string[] = [];

  for (let i = 0; i < content.items.length; i++) {
    const prefix = content.ordered ? `${i + 1}.` : '-';
    lines.push(`${prefix} ${content.items[i]}`);
  }

  lines.push('');
  return lines;
}

/**
 * Renders table.
 * @param content - Table content
 * @returns Lines of rendered table
 */
function renderTable(content: { headers: string[]; rows: string[][] }): string[] {
  const lines: string[] = [];

  // Header
  lines.push(`| ${content.headers.join(' | ')} |`);
  
  // Separator
  lines.push(`| ${content.headers.map(() => '---').join(' | ')} |`);
  
  // Rows
  for (const row of content.rows) {
    lines.push(`| ${row.join(' | ')} |`);
  }

  lines.push('');
  return lines;
}

/**
 * Renders blockquote.
 * @param content - Blockquote content
 * @returns Lines of rendered blockquote
 */
function renderBlockquote(content: { text: string; cite?: string }): string[] {
  const lines: string[] = [];

  lines.push(`> ${content.text}`);

  if (content.cite) {
    lines.push(`> — *${content.cite}*`);
  }

  lines.push('');
  return lines;
}

/**
 * Renders callout.
 * @param content - Callout content
 * @returns Lines of rendered callout
 */
function renderCallout(content: { text: string; variant?: CalloutVariant }): string[] {
  const variant = content.variant ?? 'info';
  const icons: Record<CalloutVariant, string> = {
    info: 'ℹ️',
    warning: '⚠️',
    danger: '🚨',
    success: '✅',
    tip: '💡',
  };

  const lines: string[] = [];
  lines.push(`> **${icons[variant]} ${capitalize(variant)}**`);
  lines.push('>');
  lines.push(`> ${content.text}`);
  lines.push('');

  return lines;
}

/**
 * Renders a changelog entry.
 * @param options - Changelog entry options
 * @returns Markdown string
 */
export function renderChangelogEntry(options: {
  version: string;
  date: Date | string;
  type: 'major' | 'minor' | 'patch' | 'prerelease';
  changes: Array<{
    category: string;
    items: string[];
  }>;
}): string {
  const lines: string[] = [];
  const dateStr = formatDate(
    options.date instanceof Date ? options.date : new Date(options.date),
    'yyyy-MM-dd'
  );

  lines.push(`## [${options.version}] - ${dateStr}`);
  lines.push('');

  for (const change of options.changes) {
    lines.push(`### ${change.category}`);
    lines.push('');
    for (const item of change.items) {
      lines.push(`- ${item}`);
    }
    lines.push('');
  }

  return lines.join('\n');
}

/**
 * Renders API documentation.
 * @param options - API documentation options
 * @returns Markdown string
 */
export function renderApiDoc(options: {
  endpoint: string;
  method: string;
  path?: string;
  description?: string;
  parameters?: Array<{
    name: string;
    type: string;
    required: boolean;
    description: string;
    location: 'path' | 'query' | 'body' | 'header';
  }>;
  requestBody?: {
    contentType: string;
    schema: string;
    example?: string;
  };
  responses?: Array<{
    status: number;
    description: string;
    example?: string;
  }>;
}): string {
  const lines: string[] = [];

  // Endpoint header
  const methodBadge = `\`${options.method.toUpperCase()}\``;
  lines.push(`### ${methodBadge} ${options.endpoint}`);
  lines.push('');

  if (options.description) {
    lines.push(options.description);
    lines.push('');
  }

  // Parameters
  if (options.parameters && options.parameters.length > 0) {
    lines.push('#### Parameters');
    lines.push('');

    const groupedParams = groupBy(options.parameters, (p) => p.location);
    for (const [location, params] of Object.entries(groupedParams)) {
      lines.push(`**${capitalize(location)} Parameters**`);
      lines.push('');
      lines.push('| Name | Type | Required | Description |');
      lines.push('|------|------|----------|-------------|');
      for (const param of params) {
        const required = param.required ? 'Yes' : 'No';
        lines.push(`| ${param.name} | \`${param.type}\` | ${required} | ${param.description} |`);
      }
      lines.push('');
    }
  }

  // Request body
  if (options.requestBody) {
    lines.push('#### Request Body');
    lines.push('');
    lines.push(`**Content-Type:** \`${options.requestBody.contentType}\``);
    lines.push('');
    lines.push('```json');
    lines.push(options.requestBody.schema);
    lines.push('```');
    lines.push('');
  }

  // Responses
  if (options.responses && options.responses.length > 0) {
    lines.push('#### Responses');
    lines.push('');

    for (const response of options.responses) {
      const statusClass = response.status < 400 ? 'success' : 'danger';
      lines.push(`**${response.status}** - ${response.description}`);
      lines.push('');
    }
  }

  return lines.join('\n');
}

/**
 * Compiles a markdown template string with variables.
 * @param template - Template string with {{variable}} placeholders
 * @param variables - Variables to substitute
 * @returns Compiled markdown string
 */
export function compileTemplate(
  template: string,
  variables: Record<string, unknown>
): string {
  return template.replace(/\{\{(\w+)(?:\.(\w+))?\}\}/g, (match, key, nested) => {
    const value = variables[key];
    if (value === undefined) {
      return match;
    }
    if (nested && typeof value === 'object' && value !== null) {
      return String((value as Record<string, unknown>)[nested] ?? match);
    }
    return String(value);
  });
}

/**
 * Converts markdown to HTML.
 * @param markdown - Markdown string
 * @returns HTML string
 */
export function markdownToHtml(markdown: string): string {
  marked.setOptions({
    gfm: true,
    breaks: true,
  });

  return marked(markdown) as string;
}

// Helper function for grouping
function groupBy<T>(
  array: T[],
  keyFn: (item: T) => string
): Record<string, T[]> {
  const result: Record<string, T[]> = {};
  for (const item of array) {
    const key = keyFn(item);
    if (!result[key]) {
      result[key] = [];
    }
    result[key].push(item);
  }
  return result;
}
