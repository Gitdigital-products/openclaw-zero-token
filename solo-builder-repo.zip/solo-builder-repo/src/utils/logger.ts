/**
 * Logging Utilities Module
 * 
 * Provides structured logging capabilities with multiple output formats
 * and configurable log levels.
 */

import winston from 'winston';
import { format } from '../utils/formatter';

/**
 * Log level type definition.
 */
export type LogLevel = 'trace' | 'debug' | 'info' | 'warn' | 'error';

/**
 * Log format type definition.
 */
export type LogFormat = 'json' | 'pretty' | 'simple';

/**
 * Log destination type definition.
 */
export type LogDestination = 'console' | 'file' | 'syslog';

/**
 * Logger configuration options.
 */
export interface LoggerOptions {
  level: LogLevel;
  format: LogFormat;
  destinations?: LogDestination[];
  file?: {
    path: string;
    maxSize: string;
    maxFiles: number;
  };
}

/**
 * Log entry metadata.
 */
export interface LogMetadata {
  [key: string]: unknown;
}

/**
 * Logger class providing structured logging.
 */
export class Logger {
  private logger: winston.Logger;
  private level: LogLevel;

  /**
   * Level priority mapping.
   */
  private static readonly LEVELS: Record<LogLevel, number> = {
    trace: 0,
    debug: 1,
    info: 2,
    warn: 3,
    error: 4,
  };

  /**
   * Creates a new Logger instance.
   * @param options - Logger configuration options
   */
  constructor(options: LoggerOptions) {
    this.level = options.level;

    const transports = this.createTransports(options);

    this.logger = winston.createLogger({
      level: options.level,
      levels: Logger.LEVELS,
      format: this.createFormat(options.format),
      transports,
      exitOnError: false,
    });
  }

  /**
   * Creates the appropriate transports based on configuration.
   * @param options - Logger options
   * @returns Array of winston transports
   */
  private createTransports(options: LoggerOptions): winston.transport[] {
    const transports: winston.transport[] = [];
    const destinations = options.destinations ?? ['console'];

    if (destinations.includes('console')) {
      transports.push(
        new winston.transports.Console({
          format: winston.format.combine(
            winston.format.colorize({ all: options.format === 'pretty' }),
            this.createFormat(options.format)
          ),
        })
      );
    }

    if (destinations.includes('file') && options.file) {
      transports.push(
        new winston.transports.File({
          filename: options.file.path,
          maxsize: this.parseSize(options.file.maxSize),
          maxFiles: options.file.maxFiles,
          format: this.createFormat('json'),
        })
      );
    }

    return transports;
  }

  /**
   * Creates the appropriate format based on configuration.
   * @param logFormat - Log format type
   * @returns Winston format
   */
  private createFormat(logFormat: LogFormat): winston.Format {
    switch (logFormat) {
      case 'json':
        return winston.format.combine(
          winston.format.timestamp(),
          winston.format.errors({ stack: true }),
          winston.format.json()
        );

      case 'pretty':
        return winston.format.combine(
          winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
          winston.format.errors({ stack: true }),
          winston.format.printf(({ level, message, timestamp, ...metadata }) => {
            const metaStr = Object.keys(metadata).length
              ? `\n${JSON.stringify(metadata, null, 2)}`
              : '';
            return `[${timestamp}] ${level}: ${message}${metaStr}`;
          })
        );

      case 'simple':
        return winston.format.combine(
          winston.format.timestamp(),
          winston.format.errors({ stack: true }),
          winston.format.printf(({ timestamp, level, message }) => {
            return `[${timestamp}] ${level.toUpperCase()}: ${message}`;
          })
        );

      default:
        return winston.format.json();
    }
  }

  /**
   * Parses size string to bytes.
   * @param size - Size string (e.g., '10m', '1g')
   * @returns Size in bytes
   */
  private parseSize(size: string): number {
    const match = size.match(/^(\d+)([kmg]?)$/i);
    if (!match) {
      return 10 * 1024 * 1024; // Default 10MB
    }

    const value = parseInt(match[1], 10);
    const unit = match[2].toLowerCase();

    switch (unit) {
      case 'k':
        return value * 1024;
      case 'm':
        return value * 1024 * 1024;
      case 'g':
        return value * 1024 * 1024 * 1024;
      default:
        return value;
    }
  }

  /**
   * Logs a message at the trace level.
   * @param message - Log message
   * @param metadata - Additional metadata
   */
  trace(message: string, metadata?: LogMetadata): void {
    this.logger.log('trace', message, metadata);
  }

  /**
   * Logs a message at the debug level.
   * @param message - Log message
   * @param metadata - Additional metadata
   */
  debug(message: string, metadata?: LogMetadata): void {
    this.logger.debug(message, metadata);
  }

  /**
   * Logs a message at the info level.
   * @param message - Log message
   * @param metadata - Additional metadata
   */
  info(message: string, metadata?: LogMetadata): void {
    this.logger.info(message, metadata);
  }

  /**
   * Logs a message at the warn level.
   * @param message - Log message
   * @param metadata - Additional metadata
   */
  warn(message: string, metadata?: LogMetadata): void {
    this.logger.warn(message, metadata);
  }

  /**
   * Logs a message at the error level.
   * @param message - Log message
   * @param metadata - Additional metadata
   */
  error(message: string, metadata?: LogMetadata): void {
    this.logger.error(message, metadata);
  }

  /**
   * Logs an error with stack trace.
   * @param message - Log message
   * @param error - Error object
   * @param metadata - Additional metadata
   */
  errorWithStack(message: string, error: Error, metadata?: LogMetadata): void {
    this.logger.error(message, {
      ...metadata,
      error: {
        message: error.message,
        name: error.name,
        stack: error.stack,
      },
    });
  }

  /**
   * Creates a child logger with additional context.
   * @param context - Additional context to add to all logs
   * @returns New Logger instance with context
   */
  child(context: LogMetadata): Logger {
    const childLogger = new Logger({
      level: this.level,
      format: 'json',
      destinations: ['console'],
    });

    // Create a wrapper that includes the context
    const originalLogger = childLogger.logger;
    childLogger.logger = winston.createLogger({
      level: this.level,
      levels: Logger.LEVELS,
      format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.errors({ stack: true }),
        winston.format.json()
      ),
      transports: originalLogger.transports,
    });

    return childLogger;
  }

  /**
   * Checks if a log level is enabled.
   * @param level - Log level to check
   * @returns True if the level is enabled
   */
  isLevelEnabled(level: LogLevel): boolean {
    return Logger.LEVELS[level] >= Logger.LEVELS[this.level];
  }

  /**
   * Gets the current log level.
   * @returns Current log level
   */
  getLevel(): LogLevel {
    return this.level;
  }

  /**
   * Sets the log level.
   * @param level - New log level
   */
  setLevel(level: LogLevel): void {
    this.level = level;
    this.logger.level = level;
  }

  /**
   * Closes the logger and flushes pending writes.
   * @returns Promise that resolves when logger is closed
   */
  async close(): Promise<void> {
    return new Promise((resolve) => {
      this.logger.on('finish', () => {
        resolve();
      });
      this.logger.end();
    });
  }
}

// Export a default logger instance
export const logger = new Logger({
  level: 'info',
  format: 'pretty',
});
