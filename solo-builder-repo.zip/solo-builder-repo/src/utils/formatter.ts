/**
 * Formatting Utilities Module
 * 
 * Provides utilities for formatting dates, numbers, text, and data structures.
 */

import {
  format as dateFnsFormat,
  parseISO,
  formatDistanceToNow,
  isValid,
} from 'date-fns';

/**
 * Date format presets.
 */
export const DATE_FORMATS = {
  /** ISO 8601 format: 2024-01-15T10:30:00.000Z */
  ISO: "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
  /** Date only: 2024-01-15 */
  DATE: 'yyyy-MM-dd',
  /** Time only: 10:30:00 */
  TIME: 'HH:mm:ss',
  /** Human readable: January 15, 2024 */
  HUMANDATE: 'MMMM d, yyyy',
  /** Short date: 01/15/2024 */
  SHORTDATE: 'MM/dd/yyyy',
  /** European date: 15/01/2024 */
  EUDATE: 'dd/MM/yyyy',
  /** DateTime short: Jan 15, 2024 10:30 AM */
  DATETIME: 'MMM d, yyyy h:mm a',
} as const;

/**
 * Currency code to symbol mapping.
 */
const CURRENCY_SYMBOLS: Record<string, string> = {
  USD: '$',
  EUR: '€',
  GBP: '£',
  JPY: '¥',
  CNY: '¥',
  KRW: '₩',
  INR: '₹',
  BRL: 'R$',
  CAD: 'C$',
  AUD: 'A$',
};

/**
 * Formats a date value.
 * @param value - Date value (Date, string, or timestamp)
 * @param formatString - Format string (or preset from DATE_FORMATS)
 * @returns Formatted date string
 */
export function formatDate(
  value: Date | string | number,
  formatString: string = DATE_FORMATS.ISO
): string {
  try {
    let date: Date;

    if (value instanceof Date) {
      date = value;
    } else if (typeof value === 'string') {
      date = parseISO(value);
    } else {
      date = new Date(value);
    }

    if (!isValid(date)) {
      return 'Invalid Date';
    }

    return dateFnsFormat(date, formatString);
  } catch {
    return 'Invalid Date';
  }
}

/**
 * Formats a date as relative time (e.g., "2 hours ago").
 * @param value - Date value
 * @param addSuffix - Add "ago" or "in X" suffix
 * @returns Relative time string
 */
export function formatRelativeTime(
  value: Date | string | number,
  addSuffix: boolean = true
): string {
  try {
    let date: Date;

    if (value instanceof Date) {
      date = value;
    } else if (typeof value === 'string') {
      date = parseISO(value);
    } else {
      date = new Date(value);
    }

    if (!isValid(date)) {
      return 'Invalid Date';
    }

    return formatDistanceToNow(date, { addSuffix });
  } catch {
    return 'Invalid Date';
  }
}

/**
 * Formats a number as currency.
 * @param value - Number to format
 * @param currency - Currency code (ISO 4217)
 * @param options - Formatting options
 * @returns Formatted currency string
 */
export function formatCurrency(
  value: number,
  currency: string = 'USD',
  options: {
    decimals?: number;
    showSymbol?: boolean;
    locale?: string;
  } = {}
): string {
  const { decimals = 2, showSymbol = true, locale = 'en-US' } = options;

  const symbol = showSymbol ? CURRENCY_SYMBOLS[currency] ?? currency + ' ' : '';
  const formatted = value.toLocaleString(locale, {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });

  return `${symbol}${formatted}`;
}

/**
 * Formats a number with thousand separators.
 * @param value - Number to format
 * @param options - Formatting options
 * @returns Formatted number string
 */
export function formatNumber(
  value: number,
  options: {
    decimals?: number;
    decimalSeparator?: string;
    thousandSeparator?: string;
  } = {}
): string {
  const { decimals = 0, decimalSeparator = '.', thousandSeparator = ',' } = options;

  const parts = value.toFixed(decimals).split('.');
  parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, thousandSeparator);

  return parts.join(decimalSeparator);
}

/**
 * Formats a percentage value.
 * @param value - Value between 0 and 1 (or 0 and 100 if multiplier is false)
 * @param options - Formatting options
 * @returns Formatted percentage string
 */
export function formatPercentage(
  value: number,
  options: {
    decimals?: number;
    multiplier?: boolean;
    showSign?: boolean;
  } = {}
): string {
  const { decimals = 1, multiplier = true, showSign = false } = options;

  let percentage = multiplier ? value * 100 : value;

  if (showSign && percentage > 0) {
    return `+${percentage.toFixed(decimals)}%`;
  }

  return `${percentage.toFixed(decimals)}%`;
}

/**
 * Formats a file size in human-readable form.
 * @param bytes - Size in bytes
 * @param options - Formatting options
 * @returns Formatted size string
 */
export function formatFileSize(
  bytes: number,
  options: {
    decimals?: number;
    separator?: string;
  } = {}
): string {
  const { decimals = 2, separator = ' ' } = options;

  if (bytes === 0) return '0 Bytes';

  const units = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB'];
  const k = 1024;
  const i = Math.floor(Math.log(bytes) / Math.log(k));

  const size = (bytes / Math.pow(k, i)).toFixed(decimals);
  return `${size}${separator}${units[i]}`;
}

/**
 * Formats a duration in human-readable form.
 * @param milliseconds - Duration in milliseconds
 * @returns Formatted duration string
 */
export function formatDuration(milliseconds: number): string {
  if (milliseconds < 0) {
    return '0ms';
  }

  if (milliseconds < 1000) {
    return `${milliseconds}ms`;
  }

  const seconds = Math.floor(milliseconds / 1000);

  if (seconds < 60) {
    return `${seconds}s`;
  }

  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = seconds % 60;

  if (minutes < 60) {
    if (remainingSeconds === 0) {
      return `${minutes}m`;
    }
    return `${minutes}m ${remainingSeconds}s`;
  }

  const hours = Math.floor(minutes / 60);
  const remainingMinutes = minutes % 60;

  if (hours < 24) {
    if (remainingMinutes === 0) {
      return `${hours}h`;
    }
    return `${hours}h ${remainingMinutes}m`;
  }

  const days = Math.floor(hours / 24);
  const remainingHours = hours % 24;

  if (remainingHours === 0) {
    return `${days}d`;
  }
  return `${days}d ${remainingHours}h`;
}

/**
 * Formats an array as a table string.
 * @param rows - Array of objects to format
 * @param options - Formatting options
 * @returns Formatted table string
 */
export function formatTable<T extends Record<string, unknown>>(
  rows: T[],
  options: {
    headers?: boolean;
    columnSeparator?: string;
    maxWidth?: number;
  } = {}
): string {
  const { headers = true, columnSeparator = ' | ', maxWidth = 80 } = options;

  if (rows.length === 0) {
    return '(empty table)';
  }

  const columns = Object.keys(rows[0]);
  
  // Calculate column widths
  const widths: Record<string, number> = {};
  for (const col of columns) {
    let maxLen = col.length;
    for (const row of rows) {
      const value = String(row[col] ?? '');
      maxLen = Math.max(maxLen, value.length);
    }
    widths[col] = Math.min(maxLen, Math.floor(maxWidth / columns.length));
  }

  // Format a row
  const formatRow = (row: T, includeHeaders: boolean): string => {
    return columns
      .map((col) => {
        const value = String(row[col] ?? '').substring(0, widths[col]);
        return value.padEnd(widths[col]);
      })
      .join(columnSeparator.trim());
  };

  // Build table
  const lines: string[] = [];

  if (headers) {
    lines.push(formatRow(rows[0] as T, true));
    lines.push(
      columns.map((col) => '-'.repeat(widths[col])).join(columnSeparator.trim())
    );
  }

  for (const row of rows) {
    lines.push(formatRow(row, false));
  }

  return lines.join('\n');
}

/**
 * Formats an object as JSON string with indentation.
 * @param obj - Object to format
 * @param indent - Indentation size
 * @returns Formatted JSON string
 */
export function formatJson(
  obj: unknown,
  indent: number = 2
): string {
  return JSON.stringify(obj, null, indent);
}

/**
 * Formats a phone number.
 * @param value - Phone number string
 * @param country - Country code for formatting
 * @returns Formatted phone number
 */
export function formatPhone(
  value: string,
  country: string = 'US'
): string {
  const digits = value.replace(/\D/g, '');

  switch (country) {
    case 'US':
    case 'CA':
      if (digits.length === 10) {
        return `(${digits.slice(0, 3)}) ${digits.slice(3, 6)}-${digits.slice(6)}`;
      }
      if (digits.length === 11 && digits[0] === '1') {
        return `+1 (${digits.slice(1, 4)}) ${digits.slice(4, 7)}-${digits.slice(7)}`;
      }
      break;
  }

  return value;
}

/**
 * Truncates text to a maximum length.
 * @param text - Text to truncate
 * @param maxLength - Maximum length
 * @param suffix - Suffix to add when truncated
 * @returns Truncated text
 */
export function truncate(
  text: string,
  maxLength: number,
  suffix: string = '...'
): string {
  if (text.length <= maxLength) {
    return text;
  }

  return text.substring(0, maxLength - suffix.length) + suffix;
}

/**
 * Converts camelCase to kebab-case.
 * @param str - String to convert
 * @returns kebab-case string
 */
export function camelToKebab(str: string): string {
  return str.replace(/([a-z])([A-Z])/g, '$1-$2').toLowerCase();
}

/**
 * Converts kebab-case to camelCase.
 * @param str - String to convert
 * @returns camelCase string
 */
export function kebabToCamel(str: string): string {
  return str.replace(/-([a-z])/g, (_, char) => char.toUpperCase());
}

/**
 * Converts snake_case to camelCase.
 * @param str - String to convert
 * @returns camelCase string
 */
export function snakeToCamel(str: string): string {
  return str.replace(/_([a-z])/g, (_, char) => char.toUpperCase());
}

/**
 * Converts camelCase to snake_case.
 * @param str - String to convert
 * @returns snake_case string
 */
export function camelToSnake(str: string): string {
  return str.replace(/([a-z])([A-Z])/g, '$1_$2').toLowerCase();
}

/**
 * Capitalizes the first letter of a string.
 * @param str - String to capitalize
 * @returns Capitalized string
 */
export function capitalize(str: string): string {
  if (!str) return '';
  return str.charAt(0).toUpperCase() + str.slice(1);
}

/**
 * Converts a string to title case.
 * @param str - String to convert
 * @returns Title cased string
 */
export function toTitleCase(str: string): string {
  return str.replace(
    /\w\S*/g,
    (txt) => txt.charAt(0).toUpperCase() + txt.substring(1).toLowerCase()
  );
}

/**
 * Escapes HTML special characters.
 * @param str - String to escape
 * @returns Escaped string
 */
export function escapeHtml(str: string): string {
  const escapeMap: Record<string, string> = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;',
  };

  return str.replace(/[&<>"']/g, (char) => escapeMap[char]);
}

/**
 * Unescapes HTML entities.
 * @param str - String to unescape
 * @returns Unescaped string
 */
export function unescapeHtml(str: string): string {
  const unescapeMap: Record<string, string> = {
    '&amp;': '&',
    '&lt;': '<',
    '&gt;': '>',
    '&quot;': '"',
    '&#39;': "'",
  };

  return str.replace(/&amp;|&lt;|&gt;|&quot;|&#39;/g, (entity) => unescapeMap[entity]);
}
