/**
 * Input Validation Module
 * 
 * Provides comprehensive validation for input data.
 * Supports schema-based validation with custom rules.
 */

import { Logger } from '../utils/logger';
import { isPlainObject, isString, isNumber, isBoolean, isArray } from './helpers';

/**
 * Validation rule function type.
 */
export type ValidationRule = (
  value: unknown,
  data?: Record<string, unknown>
) => boolean | string;

/**
 * Validation schema definition.
 */
export interface ValidationSchema {
  [key: string]: ValidationRule | ValidationRule[] | ValidationSchema;
}

/**
 * Validation error details.
 */
export interface ValidationError {
  field: string;
  message: string;
  value?: unknown;
}

/**
 * Validation result.
 */
export interface ValidationResult {
  valid: boolean;
  data?: unknown;
  errors: ValidationError[];
}

/**
 * Validator class for input validation.
 */
export class Validator {
  private logger: Logger;
  private initialized: boolean = false;

  /**
   * Creates a new Validator instance.
   * @param logger - Logger instance for recording validation events
   */
  constructor(logger: Logger) {
    this.logger = logger;
  }

  /**
   * Initializes the validator.
   * @returns Promise that resolves when initialization is complete
   */
  async initialize(): Promise<void> {
    if (this.initialized) {
      this.logger.warn('Validator already initialized');
      return;
    }

    this.logger.debug('Initializing validator');
    this.initialized = true;
  }

  /**
   * Validates data against a schema.
   * @param data - Data to validate
   * @param schema - Validation schema
   * @returns Validation result
   */
  validate(data: unknown, schema?: ValidationSchema): ValidationResult {
    if (!this.initialized) {
      throw new Error('Validator not initialized');
    }

    const errors: ValidationError[] = [];

    // If no schema provided, perform basic type validation
    if (!schema) {
      return this.basicValidation(data);
    }

    // Validate against schema
    const validatedData = this.validateSchema(data, schema, '', errors);

    return {
      valid: errors.length === 0,
      data: validatedData,
      errors,
    };
  }

  /**
   * Performs basic type validation.
   * @param data - Data to validate
   * @returns Basic validation result
   */
  private basicValidation(data: unknown): ValidationResult {
    const errors: ValidationError[] = [];

    if (data === null) {
      errors.push({ field: 'root', message: 'Value cannot be null' });
    }

    if (data === undefined) {
      errors.push({ field: 'root', message: 'Value cannot be undefined' });
    }

    return {
      valid: errors.length === 0,
      data,
      errors,
    };
  }

  /**
   * Validates data against a schema recursively.
   * @param data - Data to validate
   * @param schema - Validation schema
   * @param path - Current path in the data structure
   * @param errors - Array to collect errors
   * @returns Validated data
   */
  private validateSchema(
    data: unknown,
    schema: ValidationSchema,
    path: string,
    errors: ValidationError[]
  ): unknown {
    const dataObj = isPlainObject(data) ? (data as Record<string, unknown>) : {};

    for (const field in schema) {
      const fieldPath = path ? `${path}.${field}` : field;
      const rules = schema[field];

      if (isPlainObject(rules)) {
        // Nested schema
        const nestedData = dataObj[field];
        this.validateSchema(nestedData, rules as ValidationSchema, fieldPath, errors);
      } else {
        // Validation rules
        const value = dataObj[field];
        const ruleList = Array.isArray(rules) ? rules : [rules];

        for (const rule of ruleList) {
          if (typeof rule === 'function') {
            const result = rule(value, dataObj);
            
            if (result === false) {
              errors.push({
                field: fieldPath,
                message: `Validation failed for field ${field}`,
                value,
              });
            } else if (typeof result === 'string') {
              errors.push({
                field: fieldPath,
                message: result,
                value,
              });
            }
          }
        }
      }
    }

    return data;
  }

  /**
   * Creates a validation rule.
   * @param validator - Validator function
   * @param message - Error message
   * @returns Validation rule
   */
  static rule(validator: (value: unknown) => boolean, message: string): ValidationRule {
    return (value: unknown) => {
      const result = validator(value);
      return result === true ? true : message;
    };
  }

  /**
   * Creates a required validation rule.
   * @returns Validation rule
   */
  static required(): ValidationRule {
    return (value: unknown) => {
      if (value === null || value === undefined || value === '') {
        return 'Field is required';
      }
      return true;
    };
  }

  /**
   * Creates a string validation rule.
   * @param options - Validation options
   * @returns Validation rule
   */
  static string(options?: {
    minLength?: number;
    maxLength?: number;
    pattern?: RegExp;
  }): ValidationRule {
    return (value: unknown) => {
      if (!isString(value)) {
        return 'Value must be a string';
      }

      if (options?.minLength && value.length < options.minLength) {
        return `Value must be at least ${options.minLength} characters`;
      }

      if (options?.maxLength && value.length > options.maxLength) {
        return `Value must be at most ${options.maxLength} characters`;
      }

      if (options?.pattern && !options.pattern.test(value)) {
        return 'Value does not match required pattern';
      }

      return true;
    };
  }

  /**
   * Creates a number validation rule.
   * @param options - Validation options
   * @returns Validation rule
   */
  static number(options?: {
    min?: number;
    max?: number;
    integer?: boolean;
  }): ValidationRule {
    return (value: unknown) => {
      if (!isNumber(value)) {
        return 'Value must be a number';
      }

      if (options?.integer && !Number.isInteger(value)) {
        return 'Value must be an integer';
      }

      if (options?.min !== undefined && value < options.min) {
        return `Value must be at least ${options.min}`;
      }

      if (options?.max !== undefined && value > options.max) {
        return `Value must be at most ${options.max}`;
      }

      return true;
    };
  }

  /**
   * Creates a boolean validation rule.
   * @returns Validation rule
   */
  static boolean(): ValidationRule {
    return (value: unknown) => {
      if (!isBoolean(value)) {
        return 'Value must be a boolean';
      }
      return true;
    };
  }

  /**
   * Creates an array validation rule.
   * @param options - Validation options
   * @returns Validation rule
   */
  static array(options?: {
    minLength?: number;
    maxLength?: number;
    itemSchema?: ValidationSchema;
  }): ValidationRule {
    return (value: unknown) => {
      if (!isArray(value)) {
        return 'Value must be an array';
      }

      if (options?.minLength && value.length < options.minLength) {
        return `Array must have at least ${options.minLength} items`;
      }

      if (options?.maxLength && value.length > options.maxLength) {
        return `Array must have at most ${options.maxLength} items`;
      }

      if (options?.itemSchema) {
        for (let i = 0; i < value.length; i++) {
          const item = value[i];
          // Basic validation for array items
          // In a full implementation, this would use the schema
        }
      }

      return true;
    };
  }

  /**
   * Creates an email validation rule.
   * @returns Validation rule
   */
  static email(): ValidationRule {
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return (value: unknown) => {
      if (!isString(value)) {
        return 'Value must be a string';
      }
      if (!emailPattern.test(value)) {
        return 'Invalid email address';
      }
      return true;
    };
  }

  /**
   * Creates a URL validation rule.
   * @returns Validation rule
   */
  static url(): ValidationRule {
    return (value: unknown) => {
      if (!isString(value)) {
        return 'Value must be a string';
      }
      try {
        new URL(value);
        return true;
      } catch {
        return 'Invalid URL';
      }
    };
  }

  /**
   * Creates an enum validation rule.
   * @param allowedValues - Array of allowed values
   * @returns Validation rule
   */
  static enum(allowedValues: unknown[]): ValidationRule {
    return (value: unknown) => {
      if (!allowedValues.includes(value)) {
        return `Value must be one of: ${allowedValues.join(', ')}`;
      }
      return true;
    };
  }

  /**
   * Creates a custom validation rule.
   * @param validator - Custom validator function
   * @param message - Error message
   * @returns Validation rule
   */
  static custom(
    validator: (value: unknown, data?: Record<string, unknown>) => boolean,
    message: string
  ): ValidationRule {
    return (value: unknown, data?: Record<string, unknown>) => {
      try {
        const result = validator(value, data);
        return result === true ? true : message;
      } catch {
        return message;
      }
    };
  }
}

/**
 * Common validation schemas.
 */
export const schemas = {
  /**
   * User object schema.
   */
  user: {
    name: [Validator.required(), Validator.string({ minLength: 1, maxLength: 100 })],
    email: [Validator.required(), Validator.email()],
    age: Validator.number({ min: 0, max: 150, integer: true }),
  },

  /**
   * Pagination parameters schema.
   */
  pagination: {
    page: [Validator.required(), Validator.number({ min: 1, integer: true })],
    limit: Validator.number({ min: 1, max: 100, integer: true }),
  },

  /**
   * ID parameter schema.
   */
  id: {
    id: [Validator.required(), Validator.string({ minLength: 1 })],
  },
};
