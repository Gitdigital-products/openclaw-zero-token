/**
 * Core Processing Engine
 * 
 * Orchestrates the main processing logic of the application.
 * Handles input validation, processing coordination, and error management.
 */

import { Logger } from '../utils/logger';
import { Validator } from './validator';
import { formatDuration } from '../utils/formatter';

/**
 * Engine configuration options.
 */
export interface EngineOptions {
  concurrency: number;
  timeout: number;
}

/**
 * Processing context shared across operations.
 */
export interface ProcessingContext {
  requestId: string;
  startTime: number;
  metadata: Record<string, unknown>;
}

/**
 * Processing result for a single item.
 */
export interface ItemResult {
  success: boolean;
  data?: unknown;
  error?: string;
}

/**
 * Overall processing result.
 */
export interface ProcessingResult {
  successCount: number;
  failureCount: number;
  results: ItemResult[];
  errors: Array<{
    item: unknown;
    error: string;
    timestamp: string;
  }>;
  duration: number;
}

/**
 * Input for processing operations.
 */
export interface ProcessInput {
  type: string;
  items?: unknown[];
  options?: Record<string, unknown>;
}

/**
 * Engine class that coordinates processing operations.
 */
export class Engine {
  private logger: Logger;
  private options: EngineOptions;
  private validator: Validator;
  private initialized: boolean = false;

  /**
   * Creates a new Engine instance.
   * @param logger - Logger instance for recording operations
   * @param options - Engine configuration options
   */
  constructor(logger: Logger, options: EngineOptions) {
    this.logger = logger;
    this.options = options;
    this.validator = new Validator(logger);
  }

  /**
   * Initializes the engine and its dependencies.
   * @returns Promise that resolves when initialization is complete
   */
  async initialize(): Promise<void> {
    if (this.initialized) {
      this.logger.warn('Engine already initialized');
      return;
    }

    this.logger.debug('Initializing engine', {
      concurrency: this.options.concurrency,
      timeout: this.options.timeout,
    });

    // Initialize validator
    await this.validator.initialize();

    this.initialized = true;
    this.logger.info('Engine initialized successfully');
  }

  /**
   * Processes the input data through the engine pipeline.
   * @param input - The input data to process
   * @returns Promise that resolves with the processing result
   */
  async process(input: ProcessInput): Promise<ProcessingResult> {
    const startTime = Date.now();
    const requestId = this.generateRequestId();
    const context: ProcessingContext = {
      requestId,
      startTime,
      metadata: {},
    };

    this.logger.info('Starting processing', {
      requestId,
      type: input.type,
      itemCount: input.items?.length ?? 0,
    });

    const results: ItemResult[] = [];
    const errors: ProcessingResult['errors'] = [];

    // Validate input structure
    const validationResult = this.validateInput(input);
    if (!validationResult.valid) {
      this.logger.error('Input validation failed', {
        requestId,
        errors: validationResult.errors,
      });

      return {
        successCount: 0,
        failureCount: 1,
        results: [],
        errors: [
          {
            item: input,
            error: validationResult.errors.join('; '),
            timestamp: new Date().toISOString(),
          },
        ],
        duration: Date.now() - startTime,
      };
    }

    // Process items with concurrency control
    const items = input.items ?? [input];
    const batches = this.createBatches(items, this.options.concurrency);

    for (const batch of batches) {
      const batchResults = await Promise.all(
        batch.map((item) => this.processItem(item, context))
      );

      for (let i = 0; i < batchResults.length; i++) {
        const result = batchResults[i];
        results.push(result);

        if (!result.success && result.error) {
          errors.push({
            item: batch[i],
            error: result.error,
            timestamp: new Date().toISOString(),
          });
        }
      }
    }

    const duration = Date.now() - startTime;
    const successCount = results.filter((r) => r.success).length;
    const failureCount = results.filter((r) => !r.success).length;

    this.logger.info('Processing completed', {
      requestId,
      successCount,
      failureCount,
      duration: formatDuration(duration),
    });

    return {
      successCount,
      failureCount,
      results,
      errors,
      duration,
    };
  }

  /**
   * Processes a single item through the pipeline.
   * @param item - The item to process
   * @param context - Processing context
   * @returns Promise that resolves with the item result
   */
  private async processItem(
    item: unknown,
    context: ProcessingContext
  ): Promise<ItemResult> {
    try {
      // Validate item
      const itemValidation = this.validator.validate(item);
      if (!itemValidation.valid) {
        return {
          success: false,
          error: `Validation failed: ${itemValidation.errors.join('; ')}`,
        };
      }

      // Apply transformations
      const transformed = this.transform(item);

      // Process the item
      const processed = await this.applyProcessing(transformed, context);

      return {
        success: true,
        data: processed,
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      this.logger.error('Item processing failed', {
        requestId: context.requestId,
        error: errorMessage,
      });

      return {
        success: false,
        error: errorMessage,
      };
    }
  }

  /**
   * Validates the input structure.
   * @param input - Input to validate
   * @returns Validation result
   */
  private validateInput(input: unknown): { valid: boolean; errors: string[] } {
    const errors: string[] = [];

    if (input === null || input === undefined) {
      errors.push('Input cannot be null or undefined');
      return { valid: false, errors };
    }

    if (typeof input === 'object') {
      const inputObj = input as Record<string, unknown>;
      
      if (!inputObj.type || typeof inputObj.type !== 'string') {
        errors.push('Input must have a type property of type string');
      }
    }

    return { valid: errors.length === 0, errors };
  }

  /**
   * Transforms an item for processing.
   * @param item - Item to transform
   * @returns Transformed item
   */
  private transform(item: unknown): unknown {
    if (typeof item !== 'object' || item === null) {
      return item;
    }

    const obj = item as Record<string, unknown>;
    const transformed: Record<string, unknown> = {};

    // Apply transformations based on item structure
    for (const key in obj) {
      if (Object.prototype.hasOwnProperty.call(obj, key)) {
        const value = obj[key];
        
        // String transformations
        if (typeof value === 'string') {
          transformed[key] = value.trim();
        } else {
          transformed[key] = value;
        }
      }
    }

    return transformed;
  }

  /**
   * Applies the main processing logic to an item.
   * @param item - Item to process
   * @param context - Processing context
   * @returns Promise that resolves with processed item
   */
  private async applyProcessing(
    item: unknown,
    context: ProcessingContext
  ): Promise<unknown> {
    // Apply timeout to processing
    return Promise.race([
      this.executeProcessing(item, context),
      new Promise<never>((_, reject) => {
        setTimeout(() => {
          reject(new Error(`Processing timeout after ${this.options.timeout}ms`));
        }, this.options.timeout);
      }),
    ]);
  }

  /**
   * Executes the actual processing logic.
   * @param item - Item to process
   * @param context - Processing context
   * @returns Promise that resolves with processed item
   */
  private async executeProcessing(
    item: unknown,
    context: ProcessingContext
  ): Promise<unknown> {
    // Simulate processing work
    await this.delay(10);

    // Add metadata to result
    return {
      ...(item as Record<string, unknown>),
      processed: true,
      processedAt: new Date().toISOString(),
      requestId: context.requestId,
    };
  }

  /**
   * Creates batches from an array for concurrent processing.
   * @param items - Items to batch
   * @param batchSize - Size of each batch
   * @returns Array of batches
   */
  private createBatches(items: unknown[], batchSize: number): unknown[][] {
    const batches: unknown[][] = [];
    
    for (let i = 0; i < items.length; i += batchSize) {
      batches.push(items.slice(i, i + batchSize));
    }

    return batches;
  }

  /**
   * Generates a unique request ID.
   * @returns Unique request ID
   */
  private generateRequestId(): string {
    const timestamp = Date.now().toString(36);
    const random = Math.random().toString(36).substring(2, 8);
    return `req_${timestamp}_${random}`;
  }

  /**
   * Delays execution for the specified milliseconds.
   * @param ms - Milliseconds to delay
   * @returns Promise that resolves after the delay
   */
  private delay(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  /**
   * Shuts down the engine and releases resources.
   * @returns Promise that resolves when shutdown is complete
   */
  async shutdown(): Promise<void> {
    this.logger.info('Shutting down engine');
    
    // Clean up resources
    this.initialized = false;
    
    this.logger.info('Engine shutdown complete');
  }
}
