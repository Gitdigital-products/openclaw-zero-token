/**
 * Core Module Index
 * 
 * Exports all core module components for easy importing.
 */

export { Engine } from './engine';
export { Validator, schemas } from './validator';

export type {
  EngineOptions,
  ProcessingContext,
  ItemResult,
  ProcessingResult,
  ProcessInput,
} from './engine';

export type {
  ValidationRule,
  ValidationSchema,
  ValidationError,
  ValidationResult,
} from './validator';
