# Configuration Reference

This document provides a comprehensive reference for all configuration options available in the Solo Builder Repository. Configuration controls the behavior of the system, enabling customization for different environments and use cases.

Configuration can be specified through multiple mechanisms with a defined precedence order. Understanding this precedence helps you configure the system correctly and understand why certain settings take effect.

## Configuration Precedence

Configuration sources are processed in the following order, with later sources overriding earlier ones:

1. **Default values** defined in the configuration schema
2. **Configuration file** (config.json or config.yaml)
3. **Environment variables**
4. **Command-line arguments**

This precedence ensures that sensible defaults are always available while providing flexibility for customization at each level.

## Configuration File

The configuration file provides structured settings in a format that is easy to review and version control.

### File Locations

The system searches for configuration files in the following locations:

- `./config.json` (local directory)
- `./config.yaml` (YAML format alternative)
- `./config/config.json` (config subdirectory)
- `~/.config/solo-builder/config.json` (user home directory)

The first valid configuration file found is used. If no configuration file exists, default values are used.

### Configuration Schema

```json
{
  "app": {
    "name": "string",
    "version": "string",
    "port": "number",
    "host": "string",
    "environment": "development | production | test"
  },
  "logging": {
    "level": "trace | debug | info | warn | error",
    "format": "json | pretty | simple",
    "destinations": ["console", "file", "syslog"],
    "file": {
      "path": "string",
      "maxSize": "string",
      "maxFiles": "number"
    }
  },
  "features": {
    "analytics": "boolean",
    "experimental": "boolean",
    "cache": "boolean"
  },
  "validation": {
    "strict": "boolean",
    "coerce": "boolean"
  },
  "processing": {
    "concurrency": "number",
    "timeout": "number",
    "retryAttempts": "number",
    "retryDelay": "number"
  },
  "database": {
    "host": "string",
    "port": "number",
    "name": "string",
    "user": "string",
    "password": "string",
    "ssl": "boolean",
    "pool": {
      "min": "number",
      "max": "number"
    }
  },
  "cache": {
    "enabled": "boolean",
    "ttl": "number",
    "maxSize": "number",
    "provider": "memory | redis"
  },
  "security": {
    "cors": {
      "enabled": "boolean",
      "origins": ["string"],
      "methods": ["string"]
    },
    "rateLimit": {
      "enabled": "boolean",
      "windowMs": "number",
      "maxRequests": "number"
    },
    "hsts": {
      "enabled": "boolean",
      "maxAge": "number"
    }
  }
}
```

## Application Configuration

### app.name

- **Type**: string
- **Default**: "solo-builder-repo"
- **Description**: The name of the application, used in logging and monitoring.

The application name appears in log entries and health check responses. Choose a descriptive name that identifies your application in monitoring systems.

### app.version

- **Type**: string
- **Default**: "1.0.0"
- **Description**: The application version, used for telemetry and debugging.

The version should match your package.json version. This value is included in startup logs and error reports.

### app.port

- **Type**: number
- **Default**: 3000
- **Description**: The port number on which the application listens.

The port must be available on your system. On Unix-like systems, ports below 1024 require root privileges.

### app.host

- **Type**: string
- **Default**: "0.0.0.0"
- **Description**: The network interface on which the application listens.

Use "0.0.0.0" to listen on all interfaces, or specify a specific IP address to listen on a specific interface.

### app.environment

- **Type**: string
- **Default**: "development"
- **Options**: "development", "production", "test"
- **Description**: The environment mode, affecting behavior like logging verbosity and feature flags.

Development mode enables verbose logging and debugging features. Production mode optimizes for performance and security. Test mode disables external integrations and enables test-specific behaviors.

## Logging Configuration

### logging.level

- **Type**: string
- **Default**: "info"
- **Options**: "trace", "debug", "info", "warn", "error"
- **Description**: The minimum log level to record.

Log levels are hierarchical. Setting "info" records info, warn, and error messages but not debug or trace messages.

### logging.format

- **Type**: string
- **Default**: "pretty"
- **Options**: "json", "pretty", "simple"
- **Description**: The log output format.

JSON format is suitable for log aggregation systems. Pretty format is human-readable with colors and formatting. Simple format is compact and human-readable without colors.

### logging.destinations

- **Type**: string[]
- **Default**: ["console"]
- **Options**: "console", "file", "syslog"
- **Description**: Output destinations for log messages.

Multiple destinations can be specified. File destinations require additional file configuration.

### logging.file.path

- **Type**: string
- **Default**: "./logs/app.log"
- **Description**: The path to the log file when file destination is enabled.

The path is relative to the project root. Ensure the containing directory exists.

### logging.file.maxSize

- **Type**: string
- **Default**: "10m"
- **Description**: Maximum size of each log file before rotation.

Use suffixes: "k" for kilobytes, "m" for megabytes, "g" for gigabytes.

### logging.file.maxFiles

- **Type**: number
- **Default**: 5
- **Description**: Number of rotated log files to retain.

Older files beyond this count are automatically deleted.

## Feature Flags

### features.analytics

- **Type**: boolean
- **Default**: true
- **Description**: Enable anonymous usage analytics.

Analytics help understand how the project is used and guide improvements. Set to false to disable analytics collection.

### features.experimental

- **Type**: boolean
- **Default**: false
- **Description**: Enable experimental features.

Experimental features are incomplete or unstable. Enable this only for testing new capabilities.

### features.cache

- **Type**: boolean
- **Default**: true
- **Description**: Enable caching of frequently accessed data.

Caching improves performance for repeated operations. Disable for testing or debugging.

## Validation Configuration

### validation.strict

- **Type**: boolean
- **Default**: true
- **Description**: Fail on the first validation error rather than collecting all errors.

Strict mode stops at the first error, providing faster feedback. Permissive mode collects all errors before reporting.

### validation.coerce

- **Type**: boolean
- **Default**: true
- **Description**: Automatically coerce input values to the expected types.

Coercion makes APIs more forgiving, converting string numbers to actual numbers, for example.

## Processing Configuration

### processing.concurrency

- **Type**: number
- **Default**: 5
- **Description**: Maximum number of concurrent operations.

Higher concurrency increases throughput but uses more memory and may overwhelm external services.

### processing.timeout

- **Type**: number
- **Default**: 30000
- **Description**: Timeout for individual operations in milliseconds.

Operations exceeding this timeout are cancelled and logged.

### processing.retryAttempts

- **Type**: number
- **Default**: 3
- **Description**: Number of retry attempts for failed operations.

Retries apply to transient failures like network timeouts. Permanent failures are not retried.

### processing.retryDelay

- **Type**: number
- **Default**: 1000
- **Description**: Delay between retry attempts in milliseconds.

Delay increases exponentially with each attempt: 1s, 2s, 4s, etc.

## Database Configuration

### database.host

- **Type**: string
- **Default**: "localhost"
- **Description**: Database server hostname or IP address.

### database.port

- **Type**: number
- **Default**: 5432
- **Description**: Database server port.

### database.name

- **Type**: string
- **Required**: true
- **Description**: Database name.

### database.user

- **Type**: string
- **Required**: true
- **Description**: Database username.

### database.password

- **Type**: string
- **Required**: true
- **Description**: Database password.

Store passwords in environment variables rather than configuration files for security.

### database.ssl

- **Type**: boolean
- **Default**: false
- **Description**: Require SSL connection to database.

Always enable SSL in production environments.

### database.pool.min

- **Type**: number
- **Default**: 2
- **Description**: Minimum number of connections in the pool.

### database.pool.max

- **Type**: number
- **Default**: 10
- **Description**: Maximum number of connections in the pool.

## Cache Configuration

### cache.enabled

- **Type**: boolean
- **Default**: true
- **Description**: Enable caching functionality.

### cache.ttl

- **Type**: number
- **Default**: 300
- **Description**: Default time-to-live for cached items in seconds.

### cache.maxSize

- **Type**: number
- **Default**: 1000
- **Description**: Maximum number of items in the cache.

### cache.provider

- **Type**: string
- **Default**: "memory"
- **Options**: "memory", "redis"
- **Description**: Cache backend provider.

Memory cache is fast but limited to single-instance deployments. Redis provides distributed caching.

## Security Configuration

### security.cors.enabled

- **Type**: boolean
- **Default**: false
- **Description**: Enable Cross-Origin Resource Sharing.

Enable CORS when the application serves requests from web browsers on different origins.

### security.cors.origins

- **Type**: string[]
- **Default**: ["*"]
- **Description**: Allowed origins for CORS requests.

Use specific origins in production rather than wildcards.

### security.cors.methods

- **Type**: string[]
- **Default**: ["GET", "POST", "PUT", "DELETE"]
- **Description**: Allowed HTTP methods for CORS requests.

### security.rateLimit.enabled

- **Type**: boolean
- **Default**: false
- **Description**: Enable rate limiting.

Rate limiting prevents abuse by limiting request frequency.

### security.rateLimit.windowMs

- **Type**: number
- **Default**: 900000
- **Description**: Time window for rate limiting in milliseconds.

Default is 15 minutes.

### security.rateLimit.maxRequests

- **Type**: number
- **Default**: 100
- **Description**: Maximum requests per window.

### security.hsts.enabled

- **Type**: boolean
- **Default**: true
- **Description**: Enable HTTP Strict Transport Security.

Always enable HSTS in production to enforce HTTPS.

### security.hsts.maxAge

- **Type**: number
- **Default**: 31536000
- **Description**: HSTS max-age header value in seconds.

Default is one year.

## Environment Variables

Environment variables provide a way to configure the application without modifying files.

### Naming Convention

Environment variable names follow a hierarchical pattern:

```
{SCOPE}_{SUBSCOPE}_{NAME}
```

Examples:

- `APP_ENV` - Application environment
- `LOG_LEVEL` - Logging level
- `DATABASE_HOST` - Database host
- `DATABASE_PORT` - Database port

### Supported Environment Variables

| Variable | Type | Equivalent Config |
|----------|------|-------------------|
| APP_ENV | string | app.environment |
| APP_PORT | number | app.port |
| APP_HOST | string | app.host |
| APP_NAME | string | app.name |
| LOG_LEVEL | string | logging.level |
| LOG_FORMAT | string | logging.format |
| DATABASE_HOST | string | database.host |
| DATABASE_PORT | number | database.port |
| DATABASE_NAME | string | database.name |
| DATABASE_USER | string | database.user |
| DATABASE_PASSWORD | string | database.password |
| DATABASE_SSL | boolean | database.ssl |
| CACHE_ENABLED | boolean | cache.enabled |
| CACHE_TTL | number | cache.ttl |
| PORT | number | app.port |

### Example Environment File

Create a `.env` file in the project root:

```bash
# Application settings
APP_ENV=production
APP_PORT=3000

# Logging
LOG_LEVEL=info
LOG_FORMAT=json

# Database
DATABASE_HOST=db.example.com
DATABASE_PORT=5432
DATABASE_NAME=myapp
DATABASE_USER=appuser
DATABASE_PASSWORD=secure-password
DATABASE_SSL=true

# Cache
CACHE_ENABLED=true
CACHE_TTL=600
```

## Command-Line Arguments

Command-line arguments provide quick overrides for development and debugging.

### Usage

```bash
npm start -- --port=8080 --log-level=debug
```

### Supported Arguments

| Argument | Type | Description |
|----------|------|-------------|
| --port | number | Override the application port |
| --host | string | Override the application host |
| --log-level | string | Override the log level |
| --env | string | Set the environment mode |
| --config | string | Path to a custom configuration file |

## Configuration Validation

The system validates configuration at startup. Invalid configuration prevents the application from starting and displays helpful error messages.

### Validation Rules

- Required fields must be present
- Types must match the expected type
- Values must be within allowed ranges
- Combinations of values must be valid

### Validation Example

```typescript
import { validateConfig } from './src/config';

try {
  const config = validateConfig();
  console.log('Configuration is valid');
} catch (error) {
  console.error('Configuration error:', error.message);
  process.exit(1);
}
```

## Configuration Profiles

Configuration profiles allow different settings for different environments.

### Profile Files

Create environment-specific configuration files:

- `config.development.json`
- `config.production.json`
- `config.test.json`

### Using Profiles

Set the profile through environment or command line:

```bash
APP_ENV=production npm start
```

The system automatically loads the corresponding profile file and merges it with the base configuration.
