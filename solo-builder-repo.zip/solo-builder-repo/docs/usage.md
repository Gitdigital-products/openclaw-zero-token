# Usage Guide

This guide provides practical instructions for using the Solo Builder Repository. Whether you are setting up a new project, running existing operations, or customizing the system for your needs, this guide covers the essential workflows and common use cases.

The examples in this guide assume you have completed the initial setup as described in the overview documentation. If you haven't set up the project yet, refer to the Getting Started section before proceeding.

## Basic Usage

The most common way to interact with the project is through the command-line interface. The package.json defines several npm scripts that handle common tasks.

### Running the Application

To run the application in development mode with hot reloading:

```bash
npm run dev
```

Development mode starts the application with additional debugging features enabled. The application watches for file changes and automatically restarts when source files are modified. This rapid feedback loop accelerates development.

To run the application in production mode:

```bash
npm run build
npm start
```

Production mode builds optimized JavaScript and runs the compiled code. Production mode disables debugging features and enables performance optimizations.

### Running Tests

To run the test suite:

```bash
npm test
```

The test runner executes all tests and reports results. Tests are organized by module, with test files located in the tests directory. The test runner watches for file changes and reruns affected tests during development.

To run tests with coverage reporting:

```bash
npm run test:coverage
```

Coverage reports show which lines of code are exercised by tests. High coverage indicates well-tested code, though coverage should be considered alongside other quality metrics.

To run specific tests:

```bash
npm test -- --testPathPattern=utils
```

The test pattern filters tests by path, allowing you to run a subset of tests.

## Configuration

The system can be configured through multiple mechanisms. Understanding these mechanisms helps you adapt the system to your environment.

### Environment Variables

Environment variables provide the most portable configuration method. They work consistently across different systems and can be set by deployment tools, containers, or system administrators.

Setting environment variables before running the application:

```bash
# Linux and macOS
export APP_ENV=production
export LOG_LEVEL=info
npm run dev

# Windows Command Prompt
set APP_ENV=production
set LOG_LEVEL=info
npm run dev

# Windows PowerShell
$env:APP_ENV="production"
$env:LOG_LEVEL="info"
npm run dev
```

### Configuration Files

Configuration files provide structured settings that are committed to version control. They are useful for default settings and environment-specific overrides.

Create a configuration file named config.json in the project root:

```json
{
  "app": {
    "name": "my-project",
    "version": "1.0.0",
    "port": 3000,
    "environment": "development"
  },
  "logging": {
    "level": "debug",
    "format": "pretty",
    "destinations": ["console", "file"]
  },
  "features": {
    "analytics": true,
    "experimental": false
  }
}
```

### Command-Line Arguments

Command-line arguments override other configuration sources. They are useful for one-off runs and debugging scenarios.

```bash
npm start -- --port=8080 --log-level=trace
```

## Common Workflows

This section describes common workflows you will use regularly during development.

### Creating a New Feature

Creating a new feature follows a consistent workflow that ensures quality and maintainability.

First, create a feature branch for your work:

```bash
git checkout -b feature/my-new-feature
```

Second, implement your feature in the appropriate module. Write tests for your implementation as you go. Run tests frequently to verify your changes work correctly.

Third, update documentation to describe your feature. Update the README if the feature changes user-facing behavior. Update code comments for internal features.

Fourth, run the full validation suite to ensure everything works together:

```bash
npm run lint
npm run type-check
npm test
npm run build
```

Finally, commit your changes with a descriptive message:

```bash
git add .
git commit -m "feat: add my new feature

This feature enables users to do X by doing Y.
It provides Z capability for scenarios involving W."
```

### Debugging Issues

When encountering issues, a systematic debugging approach helps identify root causes efficiently.

Start by gathering information about the issue. Run the application with verbose logging to see detailed operation:

```bash
npm run dev -- --log-level=trace
```

Check the application logs for error messages or warnings. Error messages often indicate what went wrong and where.

Run the test suite to verify the issue isn't already caught by tests:

```bash
npm test
```

If tests fail, examine the test output to understand what is expected versus what is happening.

Create a minimal reproduction that demonstrates the issue. Remove unrelated code until you have the smallest possible example that shows the problem.

Once you understand the issue, implement a fix. Write a test that captures the correct behavior, then implement the fix to make the test pass.

### Building for Production

When you are ready to build a production release, follow these steps to ensure a smooth deployment.

First, run the full validation suite to catch any issues:

```bash
npm run lint
npm run type-check
npm test
npm run build
```

Second, verify the build output is correct:

```bash
ls -la dist/
```

The dist directory should contain compiled JavaScript, type declarations, and source maps.

Third, test the production build locally:

```bash
npm start
```

Verify the application starts correctly and behaves as expected.

Finally, create a version tag for the release:

```bash
git tag v1.0.0
git push origin v1.0.0
```

## Working with Templates

The template system provides flexible content generation capabilities.

### Using Markdown Templates

Markdown templates generate formatted documentation from data structures:

```typescript
import { renderMarkdown } from './src/templates/markdown';

const templateData = {
  title: 'Project Report',
  date: new Date(),
  sections: [
    { heading: 'Introduction', content: 'This report...' },
    { heading: 'Results', content: 'The results show...' },
  ],
};

const markdown = renderMarkdown(templateData);
console.log(markdown);
```

### Using Configuration Templates

Configuration templates generate valid configuration files from schemas:

```typescript
import { generateConfig } from './src/templates/config';

const configData = {
  environment: 'production',
  features: ['analytics', 'logging'],
  database: { host: 'db.example.com', port: 5432 },
};

const config = generateConfig(configData);
console.log(config);
```

## Working with Data

The system provides utilities for working with common data formats.

### Validation

Validate data against schemas before processing:

```typescript
import { validate } from './src/core/validator';
import { userSchema } from './src/schemas/user';

const userData = {
  name: 'John Doe',
  email: 'john@example.com',
  age: 30,
};

const result = validate(userData, userSchema);

if (result.success) {
  console.log('Valid user data:', result.data);
} else {
  console.log('Validation errors:', result.errors);
}
```

### Formatting

Format data for display or export:

```typescript
import { formatDate, formatCurrency, formatTable } from './src/utils/formatter';

const formattedDate = formatDate(new Date(), 'yyyy-MM-dd');
const formattedCurrency = formatCurrency(1234.56, 'USD');
const table = formatTable([
  { name: 'Item 1', price: 10.00 },
  { name: 'Item 2', price: 20.00 },
]);
```

## Logging

The logging system provides structured logging for monitoring and debugging.

### Log Levels

Use appropriate log levels for different events:

```typescript
import { logger } from './src/utils/logger';

// Error: Application cannot continue
logger.error('Database connection failed', { host: 'db.example.com' });

// Warn: Potential issue that should be reviewed
logger.warn('Configuration value deprecated', { key: 'old-setting' });

// Info: Normal operational events
logger.info('Server started', { port: 3000 });

// Debug: Detailed information for troubleshooting
logger.debug('Processing request', { method: 'POST', path: '/api/users' });

// Trace: Very detailed diagnostic information
logger.trace('Entering function', { function: 'processUser', args: args });
```

### Structured Logging

Include structured metadata for better log analysis:

```typescript
logger.info('User created', {
  userId: 'usr_12345',
  email: 'user@example.com',
  plan: 'premium',
  referrer: 'marketing-site',
});
```

Structured logs can be filtered, searched, and aggregated by their fields, making it easier to find relevant entries in large log volumes.

## Error Handling

The system uses a consistent error handling pattern throughout.

### Handling Errors

Catch and handle errors appropriately:

```typescript
import { ProcessingError, ValidationError } from './src/errors';

try {
  await processData(input);
} catch (error) {
  if (error instanceof ValidationError) {
    console.log('Input validation failed:', error.message);
    console.log('Invalid fields:', error.fields);
  } else if (error instanceof ProcessingError) {
    console.log('Processing failed:', error.message);
    console.log('Operation ID:', error.operationId);
  } else {
    console.log('Unexpected error:', error);
  }
}
```

### Creating Custom Errors

Define custom errors for your domain:

```typescript
import { AppError } from './src/errors';

class PaymentError extends AppError {
  constructor(message: string, public readonly code: string) {
    super(message, 'PAYMENT_ERROR');
    this.name = 'PaymentError';
  }
}
```

## Advanced Usage

This section covers advanced usage patterns for power users.

### Custom Processors

Create custom processors for specialized processing needs:

```typescript
import { Processor } from './src/core/processor';

class CustomProcessor implements Processor {
  async process(data: InputData): Promise<OutputData> {
    // Custom processing logic
    const transformed = this.transform(data);
    const enriched = this.enrich(transformed);
    return enriched;
  }

  private transform(data: InputData): TransformedData {
    // Transformation logic
  }

  private enrich(data: TransformedData): OutputData {
    // Enrichment logic
  }
}
```

### Custom Validators

Create custom validators for domain-specific validation:

```typescript
import { createValidator, rule } from './src/core/validator';

const customValidator = createValidator({
  email: rule(
    (value) => isValidEmail(value),
    'Must be a valid email address'
  ),
  customField: rule(
    (value, data) => isValidCombination(value, data.otherField),
    'Must be valid in combination with other field'
  ),
});
```

### Plugin System

Extend functionality through plugins:

```typescript
import { registerPlugin } from './src/core/plugin';

registerPlugin('analytics', {
  onStart: (context) => { /* Initialize analytics */ },
  onProcess: (context, data) => { /* Track processing */ },
  onComplete: (context, result) => { /* Finalize analytics */ },
  onError: (context, error) => { /* Handle analytics errors */ },
});
```

## Performance Tuning

The system provides options for tuning performance in different scenarios.

### Caching

Enable caching for frequently accessed data:

```typescript
import { withCache } from './src/utils/cache';

const getUser = withCache(
  async (userId: string) => {
    return await database.users.findById(userId);
  },
  { ttl: 300, maxSize: 1000 }
);
```

### Batching

Process multiple items efficiently with batching:

```typescript
import { batchProcess } from './src/core/batch';

const results = await batchProcess(
  items,
  { batchSize: 50, concurrency: 5 },
  async (batch) => {
    return await processBatch(batch);
  }
);
```

## Troubleshooting

This section addresses common issues and their solutions.

### Application Won't Start

If the application fails to start, check the following:

1. Verify all environment variables are set correctly
2. Check that dependencies are installed: `npm install`
3. Verify the configuration file is valid JSON: `npm run validate:config`
4. Check for port conflicts: `lsof -i :3000`

### Tests Failing

If tests fail unexpectedly:

1. Run tests in isolation: `npm test -- --testPathPattern=specific`
2. Clear test cache: `npm test -- --clearCache`
3. Check for environment issues: `npm run test:debug`
4. Verify test data is correct

### Build Failures

If the build fails:

1. Clean and rebuild: `npm run clean && npm run build`
2. Check TypeScript errors: `npm run type-check`
3. Verify all dependencies are installed: `npm install`
4. Check for circular dependencies: `npm run circular-deps`

For persistent issues, enable verbose output to see detailed build logs.

## Next Steps

Now that you understand the basics, explore these resources to deepen your knowledge:

- Read the architecture documentation to understand the system design
- Review the configuration reference for all available options
- Check the API documentation for detailed function signatures
- Explore the examples directory for complete usage examples
